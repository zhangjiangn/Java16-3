create table dept (
    did integer primary key,
    dname varchar2(20),
    tel varchar2(20)
)

insert into dept values (1,'��������','111111');
insert into dept values (2,'ŵ����˹','222222');
insert into dept values (3,'��Ӱ��','333333');

select * from dept;

create table emp (
   eid integer primary key,
   ename varchar2(20),
   sex char(10),
   hire date ,
   sar number(8,2),
   did integer
)

insert into emp values (1,'��������','��',sysdate,99999,1);
insert into emp values (2,'������˹','��',sysdate,9999,2);
insert into emp values (4,'������','��',sysdate,856,2);
insert into emp values (3,'����˹��','Ů',sysdate,1364,3);

delete emp where eid = 4 ;
update emp set hire=to_date('1768-02-18','yyyy-MM-dd') where eid = 1;

select * from emp order by sar asc/desc;
select * from emp order by sar asc,eid desc;
select * from emp where sar not between 1000 and 5000 ;
select * from emp where eid in (1,2);
select * from emp where ename like '��%'
select * from emp where ename like '��%' and sar > 100 ;
select avg(sar) from emp e, dept d where e.did = d.did group by d.dname;
select max(sar) from emp e, dept d where e.did = d.did group by d.dname;
select min(sar) from emp e, dept d where e.did = d.did group by d.dname;
select count(eid),sum(sar)from emp ;
select distinct(did) from emp ; 
select * from emp where sar<1000 union select * from emp where eid = 2 ;
select * from emp where did not in (select did from dept where dname = '��������');
select d.dname ,e.ename from dept d left join emp e on d.did = e.did ;
select d.dname ,e.ename from dept d inner join emp e on d.did = e.did ;

create table history(
   hid integer primary key,
   jod varchar2(20),
   eid integer
)

insert into history values(1,'̫��',1);
insert into history values(2,'����',2);
insert into history values(3,'սʿ',3);

create table empt as select ename ,sex from emp where 1=2;

select * from empt

alter table empt modify sex varchar(20)
alter table empt drop column sex
alter table empt add sex char(10)

drop table empt
