package biz.imp;

import java.util.List;
import java.util.Set;

import dao.StudentEaxmDao;
import dao.imp.StudentEaxmDaoImp;
import po.Answer;
import po.ST;
import po.Student;
import po.TestPaper;

import tools.PageBean;
import biz.StudentEaxmBiz;

public class StudentEaxmBizImp implements StudentEaxmBiz {
	StudentEaxmDao dao = new StudentEaxmDaoImp();

	public List<TestPaper> list(int sid) {
		// TODO Auto-generated method stub
		return dao.list(sid);
	}

	public TestPaper paper(int tid) {
		// TODO Auto-generated method stub
		return dao.paper(tid);
	}

	public List<ST> Writerlist1(int tid,int did) {
		// TODO Auto-generated method stub
		return dao.Writerlist1(tid,did);
	}

	public ST Writerlist(int tid, int p) {
		// TODO Auto-generated method stub
		return dao.Writerlist(tid, p);
	}

	public PageBean pagelist(int tid) {
		// TODO Auto-generated method stub
		return dao.pagelist(tid);
	}

	public Student student(int sid) {
		// TODO Auto-generated method stub
		return dao.student(sid);
	}

	public int updaan(int wid, String s) {
		// TODO Auto-generated method stub
		return dao.updaan(wid,  s);
	}

	public List<Answer> answers(int sid) {
		// TODO Auto-generated method stub
		return dao.answers(sid);
	}

	public List<ST> Writerlist(int tid) {
		// TODO Auto-generated method stub
		return dao.Writerlist(tid);
	}

	public int uptest(int sid,int did) {
		// TODO Auto-generated method stub
		return dao.uptest(sid,did);
	}
	
}
