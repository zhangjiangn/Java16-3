package biz.imp;

import java.util.List;

import po.Answer;
import po.Scores;
import po.Subject;
import po.TestPaper;
import dao.ScoreEaxmDao;
import dao.imp.ScoreEaxmDaoImp;
import biz.ScoreEaxmBiz;

public class ScoreEaxmBizImp implements ScoreEaxmBiz {
ScoreEaxmDao dao = new  ScoreEaxmDaoImp();

public List<TestPaper> list(int sid) {
	// TODO Auto-generated method stub
	return dao.list(sid);
}

public List<TestPaper> list() {
	// TODO Auto-generated method stub
	return dao.list();
}

public List<Subject> subjects() {
	// TODO Auto-generated method stub
	return dao.subjects();
}

public List<TestPaper> sulist(int sid) {
	// TODO Auto-generated method stub
	return dao.sulist(sid);
}

public List<Scores> scores(int sid, int tid) {
	// TODO Auto-generated method stub
	return dao.scores(sid, tid);
}

public List<Scores> scores(int tid) {
	// TODO Auto-generated method stub
	return dao.scores(tid);
}

public List<Answer> answers(int tid) {
	// TODO Auto-generated method stub
	return dao.answers(tid);
}

public Scores sco(int sid) {
	// TODO Auto-generated method stub
	return dao.sco(sid);
}

}
