package dao.imp;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tools.PageBean;

import po.Direction;
import po.Paragraph;
import po.Subject;
import po.Writer;
import dao.BaseDao;
import dao.WriterListDao;

public class WriterListDaoImp implements WriterListDao {

	public List<Writer> wrList(int sid,int count,int p) {
		// TODO Auto-generated method stub
		PageBean bean = new PageBean();
		bean.setCount(count);
		bean.setPagesize(4);
		bean.setP(p);
	
		String hql = "select w from Writer w where sid = ?";
		Query query =   session.createQuery(hql);
		query.setInteger(0, sid);
		
	    
	
		return 	 query.list();

	}
	

	public int save(Writer writer,int sid){
		int a = 0;
		try {
			Subject subject =(Subject) session.get(Subject.class, sid);
			writer.setSubject(subject);
			session.beginTransaction();
			session.save(writer);
			session.getTransaction().commit();

		} catch (Exception e) {
			a=1;
		}
		return a;

	}

	public List<Object[]> object(int did ,int pid){
//		String hql = "select distinct(s.sname),s.sid,p.pname,count(w) from Writer w left join w.subject s left join w.direction d left join w.paragraph p group by s.sname,s.sid,d.did,p.pid,p.pname having d.did = 1 and p.pid = 1";
	//	String sql="select s.sid ,s.sname , count(*),p.pname from writer  w LEFT JOIN  subject s on s.sid = w.wid   left join paragraph p on p.pid = w.pid left join direction d on d.did = w.did where s.did= 1 and s.pid = 1 group by s.sname ,p.pname ,d.dname,s.sid";
		
//String sql = "select did , sid , pid , count(*) from  writer w where w.sid in (select s.sid from  subject s  where did=1 and pid= 1)   group by did , sid,pid  ";
		
//String hql="select s.sname , count(w) from  writer w  left join w.subject s  where s.direction = ? and s.paragraph = 1   group by s.sname ";
	    Direction direction =  (Direction) session.get(Direction.class, did);
	    Paragraph paragraph = (Paragraph) session.get(Paragraph.class, pid);
	    System.out.println(direction);
	    System.out.println(paragraph);
		Criteria criteria = session.createCriteria(Subject.class).setFetchMode("writers", FetchMode.JOIN).createAlias("writers", "w").add(Restrictions.eq("direction", direction)).add(Restrictions.eq("paragraph", paragraph));
		ProjectionList poProjectionList = Projections.projectionList().add(Projections.groupProperty("sname")).add(Projections.count("w.wid")).add(Projections.groupProperty("sid"));
		criteria.setProjection(poProjectionList);
		List<Object[]> list =  criteria.list();
		for (Object[] objects : list) {
			System.out.println(objects[0]);
		}
		return  criteria.list();

	}
	public List<Paragraph> paragraphs() {
		// TODO Auto-generated method stub
	
		return 	 session.createQuery("from Paragraph").list();

	}
	public List<Direction> directions() {
		// TODO Auto-generated method stub

		return session.createQuery("from Direction").list();
	}
	public Paragraph par(int pid) {
		String hql = "select p from  Paragraph p where pid = ?";
		Query query = session.createQuery(hql);
			query.setInteger(0, pid);
		return   (Paragraph) query.uniqueResult();
	}

	public Subject subjects(int id) {
          String hql = "select s from Subject s where sid = ?";
          Query query = session.createQuery(hql);
          query.setInteger(0, id);
          System.out.println(query);
		return  (Subject) query.uniqueResult();
	}

public Writer idlist(int wid){
	     Writer writer = (Writer) session.get(Writer.class, wid);
	     
	return writer;
	
}
	public int update(Writer writer,int sid) {
		int a = 0;
		try {
			Subject s=(Subject) session.get(Subject.class,sid);
			System.out.println(s);
			Writer w = (Writer)session.get(Writer.class,writer.getWid());
			System.out.println(w);
			w.setAname(writer.getAname());
			w.setSubject(s);
			w.setBname(writer.getBname());
			w.setCname(writer.getCname());
			w.setDname(writer.getDname());
			w.setWram(writer.getWram());
			w.setAllright(writer.getAllright());
			w.setChapter(writer.getChapter());
			w.setTypes(writer.getTypes());
			w.setConter(writer.getConter());
			w.setGenrn(writer.getGenrn());
			session.beginTransaction();
			session.update(w);
			session.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			a=1;
		}
		return a;
	}





}
