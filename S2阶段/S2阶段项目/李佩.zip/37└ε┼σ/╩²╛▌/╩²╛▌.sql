insert into classes values('java1633')
insert into classes values('java1632')
insert into classes values('java1631')
insert into classes values('java1634')
insert into classes values('java1635')

insert into student values('同学','123','同学',1)
insert into student values('同学1','123','同学1',2)
insert into student values('同学2','123','同学',3)
insert into student values('同学3','123','同学',4)
insert into student values('同学4','123','同学',5)



insert into acc values('admin','123','管理员')
insert into acc values('老师','123','老师')


insert into direction values('java')
insert into direction values('3g4g')
insert into direction values('网销')

insert into paragraph values('G1')
insert into paragraph values('G2')
insert into paragraph values('G3')

insert into subject values('JAVA','1','1')
insert into subject values('JAVA2','1','2')
insert into subject values('SQL','2','1')
insert into subject values('SQL2','2','2')


--JAVA第一阶段
 insert into writer values (1,'笔试','单选','JDK是( )','一种全新的程序语言','一种程序开发辅助工具',
'一种由Java写成的，并支持Java Applet的浏览器','一种游戏软件 一种游戏软件','C','简单','T1')
insert into writer values (1,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','s','implements','B','简单','T1')
insert into writer values (1,'笔试','单选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','B','简单','T1')
insert into writer values (1,'笔试','单选','Java中，哪种不可以用来限制存取权限的关键字（ ）','public','protected',
'extends','private','C','简单','T1')
insert into writer values (1,'笔试','单选','要想定义一个不能被实例化的抽象类，在类定义中必须加上修饰符( )',
'public','protected','extends','private','D','简单','T1')
insert into writer values (1,'笔试','单选','Java源文件和编译后的文件扩展名分别为（ ）',
'.class和.java','java和.class ','.class和.class','.java和.java ','B','中等','T2')
 insert into writer values (1,'笔试','单选','若已定义 {11,22,33,-66} ; 其中0≤k≤3，则对x数组元素错误的引用是(  )',
'x[5-3]','x[k]','x[k+5]','x[0]','C','中等','T2')
 insert into writer values (1,'笔试','单选',' 不能构成循环的语句是(  )',
'for 语句','while 语句','switch 语句','do while 语句','C','中等','T2')
 insert into writer values (1,'笔试','单选','哪个关键字可以抛出异常',
'transient','finally','throw','static','C','困难','T3')
 insert into writer values (1,'笔试','单选','System类在哪个包中?',
'java.util',' java.io','java.awt','java.lang','B','困难','T3')
--JAVA第二阶段
 insert into writer values (2,'笔试','单选','JDK是( )','一种全新的程序语言','一种程序开发辅助工具',
'一种由Java写成的，并支持Java Applet的浏览器','一种游戏软件 一种游戏软件','C','简单','T1')
insert into writer values (2,'笔试','多选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','BD','简单','T1')
 insert into writer values (2,'笔试','单选',' 不能构成循环的语句是(  )',
'for 语句','while 语句','switch 语句','do while 语句','C','中等','T2')
 insert into writer values (2,'笔试','单选','哪个关键字可以抛出异常',
'transient','finally','throw','static','C','困难','T3')
 insert into writer values (2,'笔试','多选','System类在哪个包中?',
'java.util',' java.io','java.awt','java.lang','BCD','困难','T3')
--java高级应用第一阶段
insert into writer values (3,'笔试','单选','JDK是( )','一种全新的程序语言','一种程序开发辅助工具',
'一种由Java写成的，并支持Java Applet的浏览器','一种游戏软件 一种游戏软件','C','简单','T1')
insert into writer values (3,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (3,'笔试','单选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','B','简单','T1')
--java高级应用第二阶段
  insert into writer values (4,'笔试','多选','第二阶段的java，JDK是( )','一种全新的程序语言','一种程序开发辅助工具',
'一种由Java写成的，并支持Java Applet的浏览器','一种游戏软件 一种游戏软件','ABC','简单','T1')
insert into writer values (4,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (4,'笔试','多选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','AB','简单','T1')
insert into writer values (4,'笔试','单选','Java中，哪种不可以用来限制存取权限的关键字（ ）','public','protected',
'extends','private','C','简单','T1')
insert into writer values (4,'笔试','多选','要想定义一个不能被实例化的抽象类，在类定义中必须加上修饰符( )',
'public','protected','extends','private','CD','简单','T1')
--sql2005第一阶段
insert into writer values (1,'笔试','单选','Java源文件和编译后的文件扩展名分别为（ ）',
'.class和.java','java和.class ','.class和.class','.java和.java ','B','中等','T2')
 insert into writer values (1,'笔试','单选','若已定义 {11,22,33,-66} ; 其中0≤k≤3，则对x数组元素错误的引用是(  )',
'x[5-3]','x[k]','x[k+5]','x[0]','C','中等','T2')
 insert into writer values (1,'笔试','多选',' 不能构成循环的语句是(  )',
'for 语句','while 语句','switch 语句','do while 语句','AC','中等','T2')
 insert into writer values (1,'笔试','单选','哪个关键字可以抛出异常',
'transient','finally','throw','static','C','困难','T3')
 insert into writer values (1,'笔试','多选','System类在哪个包中?',
'java.util',' java.io','java.awt','java.lang','BC','困难','T3')
--sql2005第二阶段
 insert into writer values (2,'笔试','单选','删除表中数据的语句是（  ）','DROP','ALTER',
'UPDATE ','DELETE','A','简单','T1')
insert into writer values (2,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (2,'笔试','单选','JDK是( )','一种全新的程序语言','一种程序开发辅助工具',
'一种由Java写成的，并支持Java Applet的浏览器','一种游戏软件 一种游戏软件','C','简单','T1')
insert into writer values (2,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (2,'笔试','单选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','B','简单','T1')
--sql2008第一阶段
insert into writer values (3,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (3,'笔试','单选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','B','简单','T1')
insert into writer values (3,'笔试','单选','Java中，哪种不可以用来限制存取权限的关键字（ ）','public','protected',
'extends','private','C','简单','T1')
insert into writer values (3,'笔试','单选','要想定义一个不能被实例化的抽象类，在类定义中必须加上修饰符( )',
'public','protected','extends','private','D','简单','T1')
insert into writer values (3,'笔试','单选','Java源文件和编译后的文件扩展名分别为（ ）',
'.class和.java','java和.class ','.class和.class','.java和.java ','B','中等','T2')
 insert into writer values (3,'笔试','单选','若已定义 {11,22,33,-66} ; 其中0≤k≤3，则对x数组元素错误的引用是(  )',
'x[5-3]','x[k]','x[k+5]','x[0]','C','中等','T2')
 insert into writer values (3,'笔试','单选',' 不能构成循环的语句是(  )',
'for 语句','while 语句','switch 语句','do while 语句','C','中等','T2')
 insert into writer values (3,'笔试','单选','哪个关键字可以抛出异常',
'transient','finally','throw','static','C','困难','T3')
 insert into writer values (3,'笔试','单选','System类在哪个包中?',
'java.util',' java.io','java.awt','java.lang','B','困难','T3')
--sql2008第二阶段
 insert into writer values (4,'笔试','单选','第二阶段的sql,删除表中数据的语句是（  ）','DROP','ALTER',
'UPDATE ','DELETE','A','简单','T1')
insert into writer values (4,'笔试','单选','Java语言中下面哪个可以用作正确的变量名称（ ）','3D',
'name','extends','implements','B','简单','T1')
insert into writer values (4,'笔试','单选','构造函数何时被调用( )','类定义时','创建对象时',
'调用对象方法时','使用对象的变量时','B','简单','T1')
insert into writer values (4,'笔试','单选','Java中，哪种不可以用来限制存取权限的关键字（ ）','public','protected',
'extends','private','C','简单','T1')
insert into writer values (4,'笔试','单选','要想定义一个不能被实例化的抽象类，在类定义中必须加上修饰符( )',
'public','protected','extends','private','D','简单','T1')
insert into writer values (4,'笔试','单选','Java源文件和编译后的文件扩展名分别为（ ）',
'.class和.java','java和.class ','.class和.class','.java和.java ','B','中等','T2')
 insert into writer values (4,'笔试','笔试','单选','若已定义 {11,22,33,-66} ; 其中0≤k≤3，则对x数组元素错误的引用是(  )',
'x[5-3]','x[k]','x[k+5]','x[0]','C''中等','T2')
 insert into writer values (4,'笔试','单选',' 不能构成循环的语句是(  )',
'for 语句','while 语句','switch 语句','do while 语句','C','中等','T2')
 insert into writer values (4,'笔试','单选','哪个关键字可以抛出异常',
'transient','finally','throw','static','C','困难','T3')
 insert into writer values (4,'笔试','单选','System类在哪个包中?',
'java.util',' java.io','java.awt','java.lang','B','困难','T3')
insert into testPaper values (1,'黄冈试卷','笔试','java1633',100,'2018-1-1 9:20:00','2018-1-1 10:20:00',60,1)
insert into testPaper values (2,'黄冈试卷','笔试','',100,'','',60,2)
insert into testPaper values (3,'黄冈试卷','笔试','java1633',100,'2018-1-1 9:20:00','2018-1-1 10:20:00',60,3)
insert into testPaper values (4,'黄冈试卷','笔试','java1633',100,'2018-1-1 9:20:00','2018-1-1 10:20:00',60,1)
insert into  s_t values (1,1)
insert into  s_t values (1,2)
insert into  s_t values (1,3)
insert into  s_t  values (1,4)
insert into  s_t values (1,6)
insert into  s_t values (1,8)
insert into  s_t values (1,7)
insert into  s_t values (1,20)
insert into  s_t values (1,15)
insert into  s_t values (1,13)
insert into  s_t values (1,21)
insert into  s_t values (1,16)
insert into  s_t values (1,11)
--第二套卷
insert into  s_t values (2,31)
insert into  s_t values (2,22)
insert into  s_t values (2,13)
insert into  s_t values (2,4)
insert into  s_t values (2,6)
insert into  s_t values (2,8)
insert into  s_t values (2,17)
insert into  s_t values (2,10)
insert into  s_t values (2,15)
insert into  s_t values (2,16)
insert into  s_t values (2,21)
insert into  s_t values (2,35)
insert into  s_t values (2,40)
--第三套卷
insert into  s_t values (3,11)
insert into  s_t values (3,12)
insert into  s_t values (3,3)
insert into  s_t values (3,9)
insert into  s_t values (3,6)
insert into  s_t values (3,11)
insert into  s_t values (3,36)
insert into  s_t values (3,20)
insert into  s_t values (3,15)
insert into  s_t values (3,33)
insert into  s_t values (3,21)
insert into s_t values (3,40)
insert into  s_t values (3,11)
--第四套卷
insert into  s_t values (4,9)
insert into  s_t values (4,11)
insert into  s_t values (4,36)
insert into  s_t values (4,4)
insert into  s_t values (4,6)
insert into  s_t values (4,8)
insert into  s_t values (4,7)
insert into  s_t values (4,20)
insert into  s_t values (4,15)
insert into  s_t values (4,23)
insert into  s_t values (4,21)
insert into  s_t values (4,16)
insert into  s_t values (4,11)

insert into answer values (1,3,1,'A','1')
insert into answer values (1,3,2,'A','1')
insert into answer values (1,3,3,'A','1')
insert into answer values (1,3,4,'A','1')
insert into answer values (1,3,5,'A','1')
insert into answer values (1,3,6,'A','1')
insert into answer values (1,3,7,'A','1')
insert into answer values (1,3,8,'A','1')
insert into answer values (1,3,9,'A','1')
insert into answer values (1,3,10,'A','1')

insert into scores values (1,3,0)

