package biz;


import java.util.List;

import po.Direction;
import po.Paragraph;
import po.Subject;
import po.Writer;
import tools.PageBean;



public interface WriterListBiz {

	public int save(Writer writer,int sid );
	public List<Paragraph> paragraphs();
	public List<Direction> directions();
	public Subject subjects(int id);
	public List<Object[]> object(int did ,int pid);
	public Writer idlist(int wid);
	public int update(Writer writer,int sid);
	public Paragraph par(int pid);
	public List<Writer> wrList(int sid,int p);
	public PageBean pagelist(int sid);
	
}
