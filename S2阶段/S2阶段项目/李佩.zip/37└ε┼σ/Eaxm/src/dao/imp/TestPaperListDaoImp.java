package dao.imp;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;



import po.Classes;
import po.ST;
import po.Subject;
import po.Writer;

import po.TestPaper;
import tools.PageBean;


import dao.TestPaperListDao;

public class TestPaperListDaoImp implements TestPaperListDao {

	public  List<TestPaper> test(int p) {
		Query query= session.createQuery("from TestPaper");
		query.setFirstResult((p-1)*6);
		query.setMaxResults(6);
		return query.list();
	}
	public PageBean pagelist() {
	    List<TestPaper> test = session.createQuery("from TestPaper").list();
		PageBean bean = new PageBean();
		bean.setCount(test.size());
		bean.setPagesize(6);
		System.out.println(bean.getPagetotal());
		System.out.println(bean.getP());
		return bean;
	}	

	public int upId(int tid) {
		int a = 0;
		try {
			   TestPaper test = (TestPaper) session.get(TestPaper.class, tid);
			   test.setState(3);
			   session.beginTransaction();
			   session.update(test);
			   session.getTransaction().commit();
		} catch (Exception e) {
			a=1;
		}

		return a;
	}

	public int delete(int tid) {
		// TODO Auto-generated method stub
		int a = 0;
		try {
			   
		
			 String sql="delete from s_t where tid = ?";
			   SQLQuery query = session.createSQLQuery(sql); 
			   query.setInteger(0, tid);
			   int d =  query.executeUpdate();
			   System.out.println(d+"hhhhhh");
			   String sql1="delete from testpaper where tid = ?";
			   SQLQuery query1 = session.createSQLQuery(sql1); 
			   query1.setInteger(0, tid);
			  int b = query1.executeUpdate();
			  System.out.println(b+"ggggggggg");
			
		} catch (Exception e) {
			a=1;
		}
		return a;
	}
	public int update(int tid,String classes,String time,String time1) {
		// TODO Auto-generated method stub
		int a = 0;
		try {
			   TestPaper t = (TestPaper) session.get(TestPaper.class, tid);
			   System.out.println("tttttttttt"+t);
			   t.setCla(classes);
			   System.out.println("hijk");
			   t.setState(1);
			   System.out.println("dddddd");
			   t.setTestTime(time);
			   System.out.println("ggggggg");
			   t.setOvertime(time1);
			   System.out.println("ggggggg");
			   session.beginTransaction();
			   session.update(t);
			   session.getTransaction().commit();
		} catch (Exception e) {
			a=1;
		}
		return a;
	}
	public int upda(int tid,String classes,String time,String time1) {
		// TODO Auto-generated method stub
		int a = 0;
		try {
			   TestPaper t = (TestPaper) session.get(TestPaper.class, tid);
			   System.out.println("tttttttttt"+t);
			   t.setCla(classes);
			   System.out.println("hijk");
			   System.out.println("dddddd");
			   t.setTestTime(time);
			   System.out.println("ggggggg");
			   t.setOvertime(time1);
			   System.out.println("ggggggg");
			   session.beginTransaction();
			   session.update(t);
			   session.getTransaction().commit();
		} catch (Exception e) {
			a=1;
		}
		return a;
	}
	public TestPaper testList(int sid){
		
		return (TestPaper) session.get(TestPaper.class, sid);
		
	}
	public List<Classes> clalist(){
		
		return session.createQuery("from Classes").list();
		
	}

	public List<Subject> subjects() {
		// TODO Auto-generated method stub
		return session.createQuery("from Subject").list();
	}

	public Subject subjects(int sid) {
          String hql = "select s from Subject s where sid = ?";
          Query query = session.createQuery(hql);
          query.setInteger(0, sid);
          System.out.println(query);
		return  (Subject) query.uniqueResult();
	}

	public List<Writer> writers(int sid,int p) {
		// TODO Auto-generated method stub
		String hql = "select w from Writer w where sid = ?";
		Query query =   session.createQuery(hql);
		query.setInteger(0, sid);
		query.setFirstResult((p-1)*6);
		query.setMaxResults(6);
		return 	 query.list();
	}

	public int insettestpaper(int[] test1, TestPaper testPaper, int sid) {
		TestPaper paper = new TestPaper();
		paper.setScore(testPaper.getScore());
		paper.setState(2);
		paper.setStime(testPaper.getStime());
		paper.setTestType(testPaper.getTestType());
		paper.setTname(testPaper.getTname());
         int a=0;
         try {
        	 Writer writer;
        	 String hql="from Writer where wid = ?";
 			session.beginTransaction();
 			for (int j = 0; j < test1.length; j++) {
 				Query query=session.createQuery(hql);
 				query.setInteger(0, test1[j]);
 				writer=(Writer) query.uniqueResult();
 			    ST st = new ST();
 			    st.setWriter(writer);
 			    st.setTestPaper(paper);
 			    paper.getSTs().add(st);
 			}
		 Subject su  = (Subject) session.get(Subject.class, sid);
		 su.getTestPapers().add(paper);
		 paper.setSubject(su);
		 session.save(paper);
		 session.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return a ;
	}
	public int insettestpaper(int a, int b, int c, int a1, int b1, int c1,TestPaper testPaper, int sid) {
		int d = 0 ;
		try {
			session.beginTransaction();
			TestPaper paper = new TestPaper();
			paper.setScore(testPaper.getScore());
			paper.setState(2);
			paper.setStime(testPaper.getStime());
			paper.setTestType(testPaper.getTestType());
			paper.setTname(testPaper.getTname());

			
			
			String sql="select wid from (";
			sql+="select top "+a+" wid from writer  where wram='��' and types='��ѡ' order by newId()";
			sql+=" union select top "+b+" wid from writer where wram='һ��' and types='��ѡ' and sid = "+sid+" order by newId()";
			sql+=" union  select top "+c+" wid from writer where wram='����' and types='��ѡ' and sid = "+sid+" order by newId()";
			sql+=" union select top "+a1+" wid from writer where wram='��' and types='��ѡ' and sid = "+sid+" order by newId()";
			sql+=" union select top "+b1+" wid from writer where wram='һ��' and types='��ѡ' and sid = "+sid+" order by newId()";
			sql+=" union select top "+c1+" wid from writer where wram='����' and types='��ѡ' and sid = "+sid+" order by newId()";
			sql+=") as t";
			System.out.println(sql);
			System.out.println("��������");
			SQLQuery query = session.createSQLQuery(sql);
			System.out.println(query);
			List qidList = query.list();
			for (Object object : qidList) {
				Writer writer = (Writer) session.get(Writer.class, Integer.parseInt(object.toString()));
				  ST st = new ST();
				  st.setWriter(writer);
				  st.setTestPaper(paper);
				  paper.getSTs().add(st);
			}
			
			 Subject su  = (Subject) session.get(Subject.class, sid);
			 su.getTestPapers().add(paper);
			 paper.setSubject(su);
			session.save(paper);
		session.getTransaction().commit();
			
		} catch (Exception e) {
			// TODO: handle exception
			d=1;
		}
		
		
		return d;
	}

	public List<TestPaper> test(int sid, int state) {
		// TODO Auto-generated method stub
		 Subject su  = (Subject) session.get(Subject.class, sid);
		 Criteria criteria = session.createCriteria(TestPaper.class).add(Restrictions.eq("subject", su)).add(Restrictions.eq("state",state ));
		return criteria.list();
	}
	public List<ST> sts (int sid){
		TestPaper paper=(TestPaper) session.get(TestPaper.class, sid);
		 Criteria criteria = session.createCriteria(ST.class).add(Restrictions.eq("testPaper", paper));
		 
		return criteria.list();
		
	}
	public PageBean pagelist(int sid){
		String hql = "select w from Writer w where sid = ?";
		Query query =   session.createQuery(hql);
		query.setInteger(0, sid);
		List<Writer> s = query.list();
		PageBean bean = new PageBean();
		bean.setCount(s.size());
		bean.setPagesize(6);
		System.out.println(bean.getPagetotal());
		System.out.println(bean.getP());
		return bean;
	}	


}
