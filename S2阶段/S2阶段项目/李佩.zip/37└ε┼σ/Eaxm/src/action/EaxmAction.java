package action;

import java.util.List;
import java.util.Set;

import biz.StudentEaxmBiz;
import biz.imp.StudentEaxmBizImp;

import po.Answer;
import po.ST;
import po.Student;
import po.TestPaper;
import tools.PageBean;

public class EaxmAction {
	private List<Answer> answers;
	private List<TestPaper> testp;
	private List<ST> wrList;
	private ST st;
	private PageBean paBean;
	private int sid;
	private static int did;
	private int p;
	private String s;
	private int wid;
	private int w;
	private TestPaper paper;
	private StudentEaxmBiz biz = new StudentEaxmBizImp();

	public String paperlist() {
		testp = biz.list(did);
		return "pap";
	}
	public String paper1() {
		wrList = biz.Writerlist1(sid, did);
		paper = biz.paper(sid);
		paBean = biz.pagelist(sid);
		answers = biz.answers(sid);
		w=answers.size();
		if (p == 0) {
			st = biz.Writerlist(sid, 1);
			paBean.setP(p);
			int a = biz.updaan(wid, s);
		}  else  if(p>w){
			int a = biz.updaan(wid, s);
			st = biz.Writerlist(sid, w);
			paBean.setP(p);

		}
		else{
			int a = biz.updaan(wid, s);
			st = biz.Writerlist(sid, p);
			paBean.setP(p);
			
		}

		System.out.println(paBean.getP());
		return "p";
	}

	public String test() {
		System.out.println("ggggggsid" + sid);
		int a = biz.uptest(sid,did);
		if (a == 0) {
			testp = biz.list(did);
			return "pap";
		}
		return null;

	}
	public String eaxman(){
		answers = biz.answers(sid);
		return "eaxm";
		
	}

	public List<TestPaper> getTestp() {
		return testp;
	}

	public void setTestp(List<TestPaper> testp) {
		this.testp = testp;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public TestPaper getPaper() {
		return paper;
	}

	public void setPaper(TestPaper paper) {
		this.paper = paper;
	}

	public List<ST> getWrList() {
		return wrList;
	}

	public void setWrList(List<ST> wrList) {
		this.wrList = wrList;
	}

	public ST getSt() {
		return st;
	}

	public void setSt(ST st) {
		this.st = st;
	}

	public PageBean getPaBean() {
		return paBean;
	}

	public void setPaBean(PageBean paBean) {
		this.paBean = paBean;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	public int getW() {
		return w;
	}
	public void setW(int w) {
		this.w = w;
	}

}
