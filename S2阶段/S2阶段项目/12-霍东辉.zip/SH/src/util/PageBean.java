package util;

import java.util.ArrayList;
import java.util.List;



public class PageBean {
private int pagesize;//ÿҳ��ʾ������
private int pagetotal;//��ҳ��
private int p;//��ǰҳ��
private int count;//����������
private List data;//��Ų�ѯ��������
public PageBean(){
	pagesize=4;
	data=new ArrayList();
}
public int getPagesize() {
	return pagesize;
}
public void setPagesize(int pagesize) {
	this.pagesize = pagesize;
}
public int getPagetotal() {
	return pagetotal;
}
public void setPagetotal(int pagetotal) {
	this.pagetotal = pagetotal;
}
public int getP() {
	return p;
}
public void setP(int up) {
	if (up<1) {
		p=1;
	}else if(up>pagetotal){
			p=pagetotal;
	}else{
		p=up;
	}
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
	pagetotal=(int)(Math.ceil(count*1.0/pagesize));
}
public List getData() {
	return data;
}
public void setData(List list) {
	data = list;
}
public void addData(Object object){
	data.add(object);
}

}
