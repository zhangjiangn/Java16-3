package action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import util.PageBean;

import dao.SjDao;
import bean.Clas;
import bean.Fx;
import bean.Jd;
import bean.Km;
import bean.Sj;
import bean.St;
import biz.SjBiz;

public class SjAction {
	private String fid;
	private String jid;
	private String kid;
	private SjBiz sjdao=new SjDao();
	private List<Fx> list;
	private List<Jd> list1;
	private List<Km> list2;
	private List<Object[]> list4;
	private PageBean pageBean;
	private Sj sj;
	private String jiandan; 
	private String yiban; 
	private String kunnan; 
	private List<Object[]> list5;
	private List<Clas> list6;
public String test(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	list=sjdao.selectFx();
	list1=sjdao.selectJd();
	list2=sjdao.selectKm();
	int up = 1;// Ĭ��Ϊ��һҳ
	int one=1;//Ĭ�Ϸ���
	int two=1;//Ĭ�Ͻ׶�
	int three=1;//Ĭ�Ͽ�Ŀ
	String ps = ServletActionContext.getRequest().getParameter("p");// ҳ��
	if (ps != null){
		up = Integer.parseInt(ps);
	}
	//System.out.println(fid+"*"+jid+"*"+kid+"*");
	if(fid!=null){
		one = Integer.parseInt(fid);
	}
	if(jid!=null){
		two = Integer.parseInt(jid);
	}
	if(kid!=null){
		three = Integer.parseInt(kid);
	}
	pageBean=sjdao.st(one, two, three,up);
	list4 = pageBean.getData();
	session.setAttribute("list4", list4);
	return "sj";
}
public String test1(){
	list=sjdao.selectFx();
	list1=sjdao.selectJd();
	list2=sjdao.selectKm();
	return "sjsj";}
@SuppressWarnings("unchecked")
public String test2(){
	
	int one=1;//Ĭ�Ϸ���
	int two=1;//Ĭ�Ͻ׶�
	int three=1;//Ĭ�Ͽ�Ŀ
	if(fid!=null){
		one = Integer.parseInt(fid);
	}
	if(jid!=null){
		two = Integer.parseInt(jid);
	}
	if(kid!=null){
		three = Integer.parseInt(kid);
	}
	int four=0;
	int five=0;
	int six=0;
	if(kunnan!=null){
		four = Integer.parseInt(kunnan);
	}
	if(jiandan!=null){
		five = Integer.parseInt(jiandan);
	}
	if(yiban!=null){
		six = Integer.parseInt(yiban);
	}
	List<St> listshiti=null;
	listshiti=sjdao.jiandan(one, two, three, "����", four);
	sjdao.jiandan(one, two, three, "��", five);
	sjdao.jiandan(one, two, three, "�е�", six);
	Fx fx=new Fx();
	fx.setFid(one);
	sj.setFx(fx);
	
	Jd jd=new Jd();
	jd.setJid(two);
	sj.setJd(jd);
	
	Km km=new Km();
	km.setKid(three);
	sj.setKm(km);
	Sj sj1=new Sj();
	sj1=sjdao.tianjiashijuan(sj);
	int ww=sj1.getSjid();
	
//�м��
	for(St ob:listshiti){
		int kk=ob.getStid();
		sjdao.zhong(ww, kk);
	}
	
	int up = 1;// Ĭ��Ϊ��һҳ
	String ps = ServletActionContext.getRequest().getParameter("p");// ҳ��
	if (ps != null){
		up = Integer.parseInt(ps);
	}
	list=sjdao.selectFx();
	list1=sjdao.selectJd();
	list2=sjdao.selectKm();
	pageBean=sjdao.st(one, two, three,up);
	list4 = pageBean.getData();

	return "sj";
}
public String test3(){
	String zz = ServletActionContext.getRequest().getParameter("zz");// ҳ��
	int up = 0;
	if (zz != null){
		 up = Integer.parseInt(zz);
	}
	list5=sjdao.shijuan(up);
	return "chakanshijuan";	
}
public String test4(){
	String zz = ServletActionContext.getRequest().getParameter("zz");// ҳ��
	int up = 0;
	if (zz != null){
		 up = Integer.parseInt(zz);
	}
sjdao.jiesukaoshi(up);
	return "sj";
	
}
public String test5(){
	list6=sjdao.selectclass();

	return "kaishikaoshi";
	
}
public String test6(){
	String zz = ServletActionContext.getRequest().getParameter("zz");// ҳ��
	int up = 0;
	if (zz != null){
		 up = Integer.parseInt(zz);
	}

	return "kaishikaoshi";
}
public String test7(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	list=sjdao.selectFx();
	list1=sjdao.selectJd();
	list2=sjdao.selectKm();
	String ps = ServletActionContext.getRequest().getParameter("p");// ҳ��
	System.out.println(ps);
	int up=1;
	if (ps != null){
		up = Integer.parseInt(ps);
	}
	pageBean=sjdao.st(up);
	list4 = pageBean.getData();
	session.setAttribute("list4", list4);
	return "xuantizujuan";
	
}
public List<Fx> getList() {
	return list;
}
public void setList(List<Fx> list) {
	this.list = list;
}
public List<Jd> getList1() {
	return list1;
}
public void setList1(List<Jd> list1) {
	this.list1 = list1;
}
public List<Km> getList2() {
	return list2;
}
public void setList2(List<Km> list2) {
	this.list2 = list2;
}
public PageBean getPageBean() {
	return pageBean;
}
public void setPageBean(PageBean pageBean) {
	this.pageBean = pageBean;
}
public List<Object[]> getList4() {
	return list4;
}
public void setList4(List<Object[]> list4) {
	this.list4 = list4;
}
public String getFid() {
	return fid;
}
public void setFid(String fid) {
	this.fid = fid;
}
public String getJid() {
	return jid;
}
public void setJid(String jid) {
	this.jid = jid;
}
public String getKid() {
	return kid;
}
public void setKid(String kid) {
	this.kid = kid;
}
public Sj getSj() {
	return sj;
}
public void setSj(Sj sj) {
	this.sj = sj;
}

public String getJiandan() {
	return jiandan;
}
public void setJiandan(String jiandan) {
	this.jiandan = jiandan;
}
public String getYiban() {
	return yiban;
}
public void setYiban(String yiban) {
	this.yiban = yiban;
}
public String getKunnan() {
	return kunnan;
}
public void setKunnan(String kunnan) {
	this.kunnan = kunnan;
}
public List<Object[]> getList5() {
	return list5;
}
public void setList5(List<Object[]> list5) {
	this.list5 = list5;
}
public List<Clas> getList6() {
	return list6;
}
public void setList6(List<Clas> list6) {
	this.list6 = list6;
}


}
