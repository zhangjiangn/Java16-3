package action;

import java.util.List;

import org.apache.struts2.ServletActionContext;

import dao.ZaixianDao;
import bean.Jd;
import bean.Sj;
import biz.ZaixianBiz;

public class ZaixianAction {
	private ZaixianBiz zaidao=new ZaixianDao();
	private List<Object[]> list1;
	private List<Object[]> list2;
	private List<Object[]> list3;
	private List<Object[]> list4;
	private List<Object[]> list5;
	private List<Object[]> list6;
	private Sj sj;
public String test(){
	list1=zaidao.selectsj();
	return "stukaoshi";
}
public String test1(){
	String sid = ServletActionContext.getRequest().getParameter("sid");
	int up=1;
	up = Integer.parseInt(sid);
	list2=zaidao.sj(up);
    list3=zaidao.st(up);
    int one=1;
 list4=zaidao.selst(one);
	return "ksks";
}
public String test2(){
	
	return "ksks";
}
public List<Object[]> getList1() {
	return list1;
}
public void setList1(List<Object[]> list1) {
	this.list1 = list1;
}
public List<Object[]> getList2() {
	return list2;
}
public void setList2(List<Object[]> list2) {
	this.list2 = list2;
}
public List<Object[]> getList3() {
	return list3;
}
public void setList3(List<Object[]> list3) {
	this.list3 = list3;
}
public Sj getSj() {
	return sj;
}
public void setSj(Sj sj) {
	this.sj = sj;
}
public List<Object[]> getList4() {
	return list4;
}
public void setList4(List<Object[]> list4) {
	this.list4 = list4;
}
public List<Object[]> getList5() {
	return list5;
}
public void setList5(List<Object[]> list5) {
	this.list5 = list5;
}
public List<Object[]> getList6() {
	return list6;
}
public void setList6(List<Object[]> list6) {
	this.list6 = list6;
}

}
