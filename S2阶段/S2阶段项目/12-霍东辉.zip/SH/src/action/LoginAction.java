package action;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import dao.LoginDao;
import bean.Student;
import bean.Uuser;
import biz.LoginBiz;

public class LoginAction {
	private String name;
	private String pwd;
	private Uuser user;
	private Student stu;
	private int role;
	private LoginBiz logindao=new LoginDao();
public String test(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	//HttpServletRequest request = ServletActionContext.getRequest();
	session.setAttribute("role", role);
	System.out.println(role);
	if (role==2||role==4) {	
		if (name!=null&&pwd!=null) {
			user=logindao.loginuser(name, pwd);
			//System.out.println(user);
			session.setAttribute("user", user);
		}else{
			return "login";
		}
	}else{
		if (role==1) {	
			if (name!=null&&pwd!=null) {
				stu=logindao.loginstu(name, pwd);
				session.setAttribute("stu", stu);
			}else{
				return "login";
			}
		}
	}
	return "index";
}

public Uuser getUuser() {
	return user;
}

public void setUuser(Uuser user) {
	this.user = user;
}
public int getRole() {
	return role;
}
public void setRole(int role) {
	this.role = role;
}

public Uuser getUser() {
	return user;
}

public void setUser(Uuser user) {
	this.user = user;
}

public Student getStu() {
	return stu;
}

public void setStu(Student stu) {
	this.stu = stu;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPwd() {
	return pwd;
}

public void setPwd(String pwd) {
	this.pwd = pwd;
}


}
