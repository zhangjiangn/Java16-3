package action;

import java.util.List;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import util.PageBean;

import dao.TkDao;
import bean.Fx;
import bean.Jd;
import bean.Km;
import bean.St;

import biz.TkBiz;

public class TkAction {
	private String fid;
	private String jid;
	private TkBiz tkDao=new TkDao();
	private List<Fx> list;
	private List<Jd> list1;
	private List<Object[]> list2;
	private List<Object[]> list4;
	private List<Km> list3;
	private St st;
	private List<Object[]> list5;
	private PageBean pageBean;
public String test(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	list=tkDao.selectFx();//����
	list1=tkDao.selectJd();//�׶�
	int one=1;
	int two=1;
	if(fid!=null||jid!=null){
		 one = Integer.parseInt(fid);
		 two = Integer.parseInt(jid);
	}
	list2=tkDao.selectSt(one,two);//��ѯ����
	//System.out.println("aaa"+fid+"bbb"+jid);
	return "st";
}
//��ѯ
public String test1(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	int up = 1;// Ĭ��Ϊ��һҳ
	String ps = ServletActionContext.getRequest().getParameter("p");// ҳ��
	//System.out.println("aaa"+zz);
	String zz = ServletActionContext.getRequest().getParameter("zz");
	String aa = ServletActionContext.getRequest().getParameter("aa");
	int three=1;
	if (ps != null){
		up = Integer.parseInt(ps);
	}
		if(zz!=null){
		three = Integer.parseInt(zz);
}
	pageBean=tkDao.st(1, 1, three,up);
	list4 = pageBean.getData();
	session.setAttribute("three", three);
	session.setAttribute("aa", aa);
	return "shiti";
}
//����
public String test2(){
	HttpSession session=ServletActionContext.getRequest().getSession();
	String bb = ServletActionContext.getRequest().getParameter("bb");
	session.setAttribute("bb", bb);
	return "tjshiti";
}
public String test3(){
	list=tkDao.selectFx();//����
	list1=tkDao.selectJd();//�׶�
	int one=1;
	int two=1;
	if(fid!=null||jid!=null){
		 one = Integer.parseInt(fid);
		 two = Integer.parseInt(jid);
	}
	list2=tkDao.selectSt(one,two);//��ѯ����
	tkDao.tianjia(st);
	return "st";
}
public String test4(){
	String ps = ServletActionContext.getRequest().getParameter("zz");
	
	
	return "shiti";
}
public List<Fx> getList() {
	return list;
}
public void setList(List<Fx> list) {
	this.list = list;
}
public List<Jd> getList1() {
	return list1;
}
public void setList1(List<Jd> list1) {
	this.list1 = list1;
}

public List<Object[]> getList2() {
	return list2;
}
public void setList2(List<Object[]> list2) {
	this.list2 = list2;
}


public List<Km> getList3() {
	return list3;
}
public void setList3(List<Km> list3) {
	this.list3 = list3;
}
public String getFid() {
	return fid;
}
public void setFid(String fid) {
	this.fid = fid;
}
public String getJid() {
	return jid;
}
public void setJid(String jid) {
	this.jid = jid;
}
public List<Object[]> getList4() {
	return list4;
}
public void setList4(List<Object[]> list4) {
	this.list4 = list4;
}
public St getSt() {
	return st;
}
public void setSt(St st) {
	this.st = st;
}
public List<Object[]> getList5() {
	return list5;
}
public void setList5(List<Object[]> list5) {
	this.list5 = list5;
}
public PageBean getPageBean() {
	return pageBean;
}
public void setPageBean(PageBean pageBean) {
	this.pageBean = pageBean;
}


}
