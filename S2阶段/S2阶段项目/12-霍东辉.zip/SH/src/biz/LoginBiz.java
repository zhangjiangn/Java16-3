package biz;

import org.hibernate.Session;

import dao.HibernateSessionFactory;
import bean.Student;
import bean.Uuser;

public interface LoginBiz {
	public Session session= HibernateSessionFactory.getSession();
public Uuser loginuser(String uname,String upwd);
public Student loginstu(String sname,String spwd);
}
