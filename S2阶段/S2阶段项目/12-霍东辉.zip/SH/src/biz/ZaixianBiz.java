package biz;

import java.util.List;

import bean.Sj;

public interface ZaixianBiz {
public List<Object[]> selectsj();
public List<Object[]> sj(int sjid);
public List<Object[]> st(int sjid);
public List<Object[]> selst(int ssid);
}
