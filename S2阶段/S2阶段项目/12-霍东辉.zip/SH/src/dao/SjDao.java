package dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import util.PageBean;

import bean.Clas;
import bean.Fx;
import bean.Jd;
import bean.Km;
import bean.Sj;
import bean.Ss;
import bean.St;
import biz.SjBiz;

public class SjDao implements SjBiz {

	public List<Fx> selectFx() {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String hql="select f from Fx f";
		Query query=session.createQuery(hql);
		List<Fx> list=query.list();
		return list;
	}

	public List<Jd> selectJd() {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String hql="select j from Jd j";
		Query query=session.createQuery(hql);
		List<Jd> list=query.list();
		return list;
	}

	public List<Km> selectKm() {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String hql="select k from Km k";
		Query query=session.createQuery(hql);
		List<Km> list=query.list();
		return list;
	}

	public PageBean st(int fid, int jid, int kid, int p) {
		PageBean pb = new PageBean();
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select * from sj s left join jd j on j." +
				"jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid " +
				"where s.fid=? and s.jid =? and s.kid=? ";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,fid);
		query.setInteger(1,jid);
		query.setInteger(2,kid);
	
		List<Object[]> list=query.list();
		int one=list.size();
		pb.setPagesize(4);//����ÿҳ��ʾ������
		if(one==0){
			one=1;
		}
		pb.setCount(one);//��¼������
		pb.setP(p);// ��ǰ�ڼ�ҳ
		System.out.println("�ڼ�ҳ"+pb.getP());
		String sql1="select top "+pb.getPagesize()+" k.kname,s.* from" +
		" sj s left join jd j on j.jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid " +
		"where s.fid=? and s.jid =? and s.kid=? and sjid not in (select top "+(pb.getP()-1)*pb.getPagesize()+" sjid from sj)";
		SQLQuery query1=session.createSQLQuery(sql1);
		query1.setInteger(0,fid);
		query1.setInteger(1,jid);
		query1.setInteger(2,kid);
		List<Object[]> list1=query1.list();
		for (int i = 0; i < list1.size(); i++) {
			pb.addData(list1.get(i));
		}
		
		return pb;
	}
//������,��ȡ����
	@SuppressWarnings("null")
	public List<St> jiandan(int fid, int jid, int kid, String nandu, int jidaos) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select s from St s,Fx f,Jd j,Km k where f.fid=? and j.jid=? and k.kid=? and s.nandu=?";
		Query query1=session.createQuery(sql);
		query1.setInteger(0,fid);
		query1.setInteger(1,jid);
		query1.setInteger(2,kid);
		query1.setString(3,nandu);
		List<St> list1=query1.list();
		Collections.shuffle(list1);
		List<St> list2 =null;
		for(int i=jidaos;i>0;i--){
			list2.add(list1.get(i-1));
		}
		return list2;
	}
//�����Ծ�
	public Sj tianjiashijuan(Sj sj) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		session.beginTransaction();
		Sj sj1=new Sj();
		sj1.setFx(sj.getFx());
		sj1.setJd(sj.getJd());
	    sj1.setKm(sj.getKm());
		sj1.setSname(sj.getSname());
		sj1.setLeixing("����");
		sj1.setZongfen(sj.getZongfen());
		sj1.setStime(sj.getStime());
		sj1.setZhuangtai("δ��ʼ");
		session.save(sj1);
		session.beginTransaction().commit();
		session.close();
		return sj1;
	}
//��Զ��м��
	public int zhong(int one, int two) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		session.beginTransaction();
		Ss ss=new Ss();
		ss.getSj().setSjid(one);
		ss.getSt().setStid(two);
		session.save(ss);
		session.beginTransaction().commit();
		session.close();
		return 0;
	}

	public List<Object[]> shijuan(int stid) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql1="select t.* from ss s,st t where s.sjid=? and s.stid=t.stid";
		SQLQuery query=session.createSQLQuery(sql1);
		query.setInteger(0,stid);
		List<Object[]> list=query.list();
		System.out.println(list.size());
		return list;
	}

	public int jiesukaoshi(int sjid) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		session.beginTransaction();
		session.beginTransaction().commit();
		Sj sj=(Sj)session.load(Sj.class, sjid);
		sj.setZhuangtai("���Խ���");
		session.update(sj);
		session.close();
		return 0;
	}

	public List<Clas> selectclass() {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String hql="select c from Clas c";
		Query query=session.createQuery(hql);
		List<Clas> list=query.list();
		return list;
	
	}

	public PageBean st(int p) {
		PageBean pb = new PageBean();
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select * from st s left join jd j on j." +
				"jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid ";
		SQLQuery query=session.createSQLQuery(sql);
	
		List<Object[]> list=query.list();
		int one=list.size();
		pb.setPagesize(8);//����ÿҳ��ʾ������
		if(one==0){
			one=1;
		}
		pb.setCount(one);//��¼������
		pb.setP(p);// ��ǰ�ڼ�ҳ
		String sql1="select top "+pb.getPagesize()+" k.kname,s.* from" +
		" st s left join jd j on j.jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid " +
		"where stid not in (select top "+(pb.getP()-1)*pb.getPagesize()+" stid from st)";
		SQLQuery query1=session.createSQLQuery(sql1);
		List<Object[]> list1=query1.list();
		for (int i = 0; i < list1.size(); i++) {
			pb.addData(list1.get(i));
		}
		
		return pb;
	}

}
