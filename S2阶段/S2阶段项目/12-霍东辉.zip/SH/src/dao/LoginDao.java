package dao;

import org.hibernate.Query;

import bean.Student;
import bean.Uuser;
import biz.LoginBiz;

public class LoginDao implements LoginBiz {

	public Student loginstu(String sname, String spwd) {
		String hql="select s from Student s where s.sname=? and s.spwd=?";
		Query query=session.createQuery(hql);
		query.setString(0,sname);
		query.setString(1,spwd);
		return (Student)query.uniqueResult();
	}

	public Uuser loginuser(String uname, String upwd) {
		String hql="select u from Uuser u where u.uname=? and u.upwd=?";
		Query query=session.createQuery(hql);
		query.setString(0,uname);
		query.setString(1,upwd);
		return (Uuser)query.uniqueResult();
	}

}
