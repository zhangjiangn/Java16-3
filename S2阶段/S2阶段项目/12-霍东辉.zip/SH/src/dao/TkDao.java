package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;

import util.PageBean;

import bean.Fx;
import bean.Jd;
import bean.Km;
import bean.St;
import bean.Student;

import biz.TkBiz;

public class TkDao implements TkBiz {

	public List<Fx> selectFx() {
		String hql="select f from Fx f";
		Query query=session.createQuery(hql);
		List<Fx> list=query.list();
		return list;
	}

	public List<Jd> selectJd() {
		String hql="select j from Jd j";
		Query query=session.createQuery(hql);
		List<Jd> list=query.list();
		return list;
	}

	public List<Km> selectKm() {
		String hql="select k from Km k";
		Query query=session.createQuery(hql);
		List<Km> list=query.list();
		return list;
	}
//����
	public List<Object[]> selectSt(int fid,int jid) {
		String sql="select k.kid,f.fname,j.jname,k.kname,count(s.kid) from " +
				"st s left join jd j on j.jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid where s.fid=? and s.jid =? " +
				"group by f.fname,j.jname,k.kname,k.kid";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,fid);
		query.setInteger(1,jid);
		List<Object[]> list=query.list();
		return list;
	}
	//��ҳ��ѯ����

	public PageBean st(int fid, int jid, int kid,int p) {
		PageBean pb = new PageBean();
		String sql="select * from st s left join jd j on j." +
				"jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid " +
				"where s.fid=? and s.jid =? and s.kid=? ";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,fid);
		query.setInteger(1,jid);
		query.setInteger(2,kid);
	
		List<Object[]> list=query.list();
		int one=list.size();
		pb.setPagesize(8);//����ÿҳ��ʾ������
		pb.setCount(one);//��¼������
		pb.setP(p);// ��ǰ�ڼ�ҳ
		String sql1="select top "+pb.getPagesize()+" * from" +
				" st s left join jd j on j.jid=s.jid left join fx f on f.fid=s.fid left join km k on k.kid=s.kid " +
				"where s.fid=? and s.jid =? and s.kid=? and stid not in(select top "+(pb.getP()-1)*pb.getPagesize()+" stid from st)";
		SQLQuery query1=session.createSQLQuery(sql1);
		query1.setInteger(0,fid);
		query1.setInteger(1,jid);
		query1.setInteger(2,kid);
		List<Object[]> list1=query1.list();
		for (int i = 0; i < list1.size(); i++) {
			pb.addData(list1.get(i));
		}
		
		return pb;
	}
//��������
	public int tianjia(St st) {
		session.beginTransaction();
		St st1=new St();
		st1.setTmtype(st.getTmtype());
		st1.setTname(st.getTname());
		st1.setAoption(st.getAoption());
		st1.setBoption(st.getBoption());
		st1.setCoption(st.getCoption());
		st1.setDoption(st.getDoption());
		st1.setDaan(st.getDaan());
		st1.setNandu(st.getNandu());
		st1.setZhangjie(st.getZhangjie());
		session.save(st1);
		session.beginTransaction().commit();
		session.close();
		return 0;
	}

	public St dange(int stid) {
		String sql="select * from st where stid=?";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,stid);
		
		return (St)query.uniqueResult();
	}

}
