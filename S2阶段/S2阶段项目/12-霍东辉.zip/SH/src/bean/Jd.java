package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Jd entity. @author MyEclipse Persistence Tools
 */

public class Jd implements java.io.Serializable {

	// Fields

	private Integer jid;
	private String jname;
	private Set kms = new HashSet(0);
	private Set sjs = new HashSet(0);
	private Set students = new HashSet(0);
	private Set sts = new HashSet(0);

	// Constructors

	/** default constructor */
	public Jd() {
	}

	/** minimal constructor */
	public Jd(Integer jid) {
		this.jid = jid;
	}

	/** full constructor */
	public Jd(Integer jid, String jname, Set kms, Set sjs, Set students, Set sts) {
		this.jid = jid;
		this.jname = jname;
		this.kms = kms;
		this.sjs = sjs;
		this.students = students;
		this.sts = sts;
	}

	// Property accessors

	public Integer getJid() {
		return this.jid;
	}

	public void setJid(Integer jid) {
		this.jid = jid;
	}

	public String getJname() {
		return this.jname;
	}

	public void setJname(String jname) {
		this.jname = jname;
	}

	public Set getKms() {
		return this.kms;
	}

	public void setKms(Set kms) {
		this.kms = kms;
	}

	public Set getSjs() {
		return this.sjs;
	}

	public void setSjs(Set sjs) {
		this.sjs = sjs;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

	public Set getSts() {
		return this.sts;
	}

	public void setSts(Set sts) {
		this.sts = sts;
	}

}