package bean;

/**
 * Ss entity. @author MyEclipse Persistence Tools
 */

public class Ss implements java.io.Serializable {

	// Fields

	private Integer ssid;
	private Sj sj;
	private St st;

	// Constructors

	/** default constructor */
	public Ss() {
	}

	/** minimal constructor */
	public Ss(Integer ssid) {
		this.ssid = ssid;
	}

	/** full constructor */
	public Ss(Integer ssid, Sj sj, St st) {
		this.ssid = ssid;
		this.sj = sj;
		this.st = st;
	}

	// Property accessors

	public Integer getSsid() {
		return this.ssid;
	}

	public void setSsid(Integer ssid) {
		this.ssid = ssid;
	}

	public Sj getSj() {
		return this.sj;
	}

	public void setSj(Sj sj) {
		this.sj = sj;
	}

	public St getSt() {
		return this.st;
	}

	public void setSt(St st) {
		this.st = st;
	}

}