package bean;

/**
 * Cj entity. @author MyEclipse Persistence Tools
 */

public class Cj implements java.io.Serializable {

	// Fields

	private Integer cid;
	private Student student;
	private String startime;
	private String overtime;
	private Integer cj;

	// Constructors

	/** default constructor */
	public Cj() {
	}

	/** minimal constructor */
	public Cj(Integer cid) {
		this.cid = cid;
	}

	/** full constructor */
	public Cj(Integer cid, Student student, String startime, String overtime,
			Integer cj) {
		this.cid = cid;
		this.student = student;
		this.startime = startime;
		this.overtime = overtime;
		this.cj = cj;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getStartime() {
		return this.startime;
	}

	public void setStartime(String startime) {
		this.startime = startime;
	}

	public String getOvertime() {
		return this.overtime;
	}

	public void setOvertime(String overtime) {
		this.overtime = overtime;
	}

	public Integer getCj() {
		return this.cj;
	}

	public void setCj(Integer cj) {
		this.cj = cj;
	}

}