package bean;

/**
 * Da entity. @author MyEclipse Persistence Tools
 */

public class Da implements java.io.Serializable {

	// Fields

	private Integer did;
	private Student student;
	private Sj sj;
	private St st;
	private String xsdaan;

	// Constructors

	/** default constructor */
	public Da() {
	}

	/** minimal constructor */
	public Da(Integer did) {
		this.did = did;
	}

	/** full constructor */
	public Da(Integer did, Student student, Sj sj, St st, String xsdaan) {
		this.did = did;
		this.student = student;
		this.sj = sj;
		this.st = st;
		this.xsdaan = xsdaan;
	}

	// Property accessors

	public Integer getDid() {
		return this.did;
	}

	public void setDid(Integer did) {
		this.did = did;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Sj getSj() {
		return this.sj;
	}

	public void setSj(Sj sj) {
		this.sj = sj;
	}

	public St getSt() {
		return this.st;
	}

	public void setSt(St st) {
		this.st = st;
	}

	public String getXsdaan() {
		return this.xsdaan;
	}

	public void setXsdaan(String xsdaan) {
		this.xsdaan = xsdaan;
	}

}