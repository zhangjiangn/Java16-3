package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Sj entity. @author MyEclipse Persistence Tools
 */

public class Sj implements java.io.Serializable {

	// Fields

	private Integer sjid;
	private Jd jd;
	private Fx fx;
	private Km km;
	private String sname;
	private String leixing;
	private String banji;
	private Integer zongfen;
	private String stime;
	private String zhuangtai;
	private Set sses = new HashSet(0);
	private Set das = new HashSet(0);

	// Constructors

	/** default constructor */
	public Sj() {
	}

	/** minimal constructor */
	public Sj(Integer sjid) {
		this.sjid = sjid;
	}

	/** full constructor */
	public Sj(Integer sjid, Jd jd, Fx fx, Km km, String sname, String leixing,
			String banji, Integer zongfen, String stime, String zhuangtai,
			Set sses, Set das) {
		this.sjid = sjid;
		this.jd = jd;
		this.fx = fx;
		this.km = km;
		this.sname = sname;
		this.leixing = leixing;
		this.banji = banji;
		this.zongfen = zongfen;
		this.stime = stime;
		this.zhuangtai = zhuangtai;
		this.sses = sses;
		this.das = das;
	}

	// Property accessors

	public Integer getSjid() {
		return this.sjid;
	}

	public void setSjid(Integer sjid) {
		this.sjid = sjid;
	}

	public Jd getJd() {
		return this.jd;
	}

	public void setJd(Jd jd) {
		this.jd = jd;
	}

	public Fx getFx() {
		return this.fx;
	}

	public void setFx(Fx fx) {
		this.fx = fx;
	}

	public Km getKm() {
		return this.km;
	}

	public void setKm(Km km) {
		this.km = km;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getLeixing() {
		return this.leixing;
	}

	public void setLeixing(String leixing) {
		this.leixing = leixing;
	}

	public String getBanji() {
		return this.banji;
	}

	public void setBanji(String banji) {
		this.banji = banji;
	}

	public Integer getZongfen() {
		return this.zongfen;
	}

	public void setZongfen(Integer zongfen) {
		this.zongfen = zongfen;
	}

	public String getStime() {
		return this.stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public String getZhuangtai() {
		return this.zhuangtai;
	}

	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}

	public Set getSses() {
		return this.sses;
	}

	public void setSses(Set sses) {
		this.sses = sses;
	}

	public Set getDas() {
		return this.das;
	}

	public void setDas(Set das) {
		this.das = das;
	}

}