package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Km entity. @author MyEclipse Persistence Tools
 */

public class Km implements java.io.Serializable {

	// Fields

	private Integer kid;
	private Jd jd;
	private Fx fx;
	private String kname;
	private Set sts = new HashSet(0);
	private Set sjs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Km() {
	}

	/** minimal constructor */
	public Km(Integer kid) {
		this.kid = kid;
	}

	/** full constructor */
	public Km(Integer kid, Jd jd, Fx fx, String kname, Set sts, Set sjs) {
		this.kid = kid;
		this.jd = jd;
		this.fx = fx;
		this.kname = kname;
		this.sts = sts;
		this.sjs = sjs;
	}

	// Property accessors

	public Integer getKid() {
		return this.kid;
	}

	public void setKid(Integer kid) {
		this.kid = kid;
	}

	public Jd getJd() {
		return this.jd;
	}

	public void setJd(Jd jd) {
		this.jd = jd;
	}

	public Fx getFx() {
		return this.fx;
	}

	public void setFx(Fx fx) {
		this.fx = fx;
	}

	public String getKname() {
		return this.kname;
	}

	public void setKname(String kname) {
		this.kname = kname;
	}

	public Set getSts() {
		return this.sts;
	}

	public void setSts(Set sts) {
		this.sts = sts;
	}

	public Set getSjs() {
		return this.sjs;
	}

	public void setSjs(Set sjs) {
		this.sjs = sjs;
	}

}