package po;

import java.util.HashSet;
import java.util.Set;

/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Paragraph paragraph;
	private Direction direction;
	private String sname;
	private Set testPapers = new HashSet(0);
	private Set writers = new HashSet(0);

	// Constructors

	/** default constructor */
	public Subject() {
	}

	/** minimal constructor */
	public Subject(Integer sid) {
		this.sid = sid;
	}

	/** full constructor */
	public Subject(Integer sid, Paragraph paragraph, Direction direction,
			String sname, Set testPapers, Set writers) {
		this.sid = sid;
		this.paragraph = paragraph;
		this.direction = direction;
		this.sname = sname;
		this.testPapers = testPapers;
		this.writers = writers;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Paragraph getParagraph() {
		return this.paragraph;
	}

	public void setParagraph(Paragraph paragraph) {
		this.paragraph = paragraph;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Set getTestPapers() {
		return this.testPapers;
	}

	public void setTestPapers(Set testPapers) {
		this.testPapers = testPapers;
	}

	public Set getWriters() {
		return this.writers;
	}

	public void setWriters(Set writers) {
		this.writers = writers;
	}

}