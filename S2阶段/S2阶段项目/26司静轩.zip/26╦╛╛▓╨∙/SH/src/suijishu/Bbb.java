package suijishu;
import java.util.Random;


public class Bbb {
	public static int[] random(int min,int max,int n){
		int len=max-min+1;
		if(max<min||n>len){
			return null;
		}
		int[]sou=new int[len];
		for (int i = min; i < min+len; i++) {
			sou[i-min]=i;
		}
		int[]result=new int[n];
		Random rd=new Random();
		int index=0;
		for (int i = 0; i < result.length; i++) {
			index=Math.abs(rd.nextInt()%len--);
			result[i]=sou[index];
			sou[index]=sou[len];
		}
		return result;
	}

}
