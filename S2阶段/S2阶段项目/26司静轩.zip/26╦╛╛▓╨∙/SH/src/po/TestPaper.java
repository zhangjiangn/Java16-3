package po;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * TestPaper entity. @author MyEclipse Persistence Tools
 */

public class TestPaper implements java.io.Serializable {

	// Fields

	private Integer tid;
	private Subject subject;
	private String tname;
	private String testType;
	private String cla;
	private Integer score;
	private Timestamp testTime;
	private Timestamp overtime;
	private Integer stime;
	private Integer state;
	private Set scoreses = new HashSet(0);
	private Set STs = new HashSet(0);
	private Set answers = new HashSet(0);

	// Constructors

	/** default constructor */
	public TestPaper() {
	}

	/** minimal constructor */
	public TestPaper(Integer tid) {
		this.tid = tid;
	}

	/** full constructor */
	public TestPaper(Integer tid, Subject subject, String tname,
			String testType, String cla, Integer score, Timestamp testTime,Timestamp overtime,
			Integer stime, Integer state, Set scoreses, Set STs, Set answers) {
		this.tid = tid;
		this.subject = subject;
		this.tname = tname;
		this.testType = testType;
		this.cla = cla;
		this.score = score;
		this.overtime = overtime;
		this.testTime = testTime;
		this.stime = stime;
		this.state = state;
		this.scoreses = scoreses;
		this.STs = STs;
		this.answers = answers;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getTestType() {
		return this.testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public String getCla() {
		return this.cla;
	}

	public void setCla(String cla) {
		this.cla = cla;
	}

	public Integer getScore() {
		return this.score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Timestamp getTestTime() {
		return this.testTime;
	}

	public void setTestTime(Timestamp testTime) {
		this.testTime = testTime;
	}

	public Integer getStime() {
		return this.stime;
	}

	public void setStime(Integer stime) {
		this.stime = stime;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Set getScoreses() {
		return this.scoreses;
	}

	public void setScoreses(Set scoreses) {
		this.scoreses = scoreses;
	}

	public Set getSTs() {
		return this.STs;
	}

	public void setSTs(Set STs) {
		this.STs = STs;
	}

	public Set getAnswers() {
		return this.answers;
	}

	public void setAnswers(Set answers) {
		this.answers = answers;
	}

	public Timestamp getOvertime() {
		return overtime;
	}

	public void setOvertime(Timestamp overtime) {
		this.overtime = overtime;
	}

}