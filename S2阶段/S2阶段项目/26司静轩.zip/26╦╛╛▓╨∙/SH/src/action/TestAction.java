package action;

import java.util.List;
import java.util.Set;

import javax.swing.JOptionPane;

import suijishu.Bbb;


import po.Classes;
import po.ST;
import po.Subject;
import po.TestPaper;
import po.Writer;
import biz.TestPaperListBiz;
import biz.imp.TestPaperListBizImp;

public class TestAction {
	private List<TestPaper> papers;
	private List<Classes> cla;
	private List<Writer> writers;
	private List<Subject> subjects;
	private List<ST> sts;
	private  String id;
	private int sid;
	private String ssid;
	private String suid;
	private String state;
	private  String cla1;
   private int easy1;
   private int commonly1;
   private int hard1;
   private int easy2;
   private int commonly2;
   private int hard2;
	private  String time;
    private TestPaper test;
	private int[] test1;
	private int[] number;
	private Integer[] idd;
	private int num;
	private TestPaperListBiz biz = new TestPaperListBizImp();
	public String test(){
		if (suid!=null && state!=null ) {
			int sid =Integer.valueOf(suid);
			int sta = Integer.valueOf(state);
			subjects = biz.subjects();
			papers = biz.test(sid, sta);
			
		} else {
			subjects = biz.subjects();
			papers = biz.test();
		}
		
		return "test";	
	}
	public String upid(){
		int a = biz.upId(sid);
		if (a==0) {
			
			papers = biz.test();  
		} 
		return "test";
	}
	public String delete(){
		int a = biz.delete(sid);
		if (a==0) {
			papers = biz.test();  
			return "test";
		}
		return null; 
		
	}
	public String list(){
	System.out.println(sid);
	test =	biz.testList(sid);
    cla =   biz.clalist();
	return "list";
		
	}
	public String update(){
		System.out.println(sid);
	    int a =	biz.update(sid,cla1,time);
	if (a==0) {
		papers = biz.test(); 
		return "test";
	}
	return null;
	}
	public String insert(){
		System.out.println(ssid);
		int tid = Integer.valueOf(ssid);
		
	    int a =	biz.insettestpaper(test1, test, tid);
	if (a==0) {
		papers = biz.test(); 
		return "test";
	}
	return null;
	}
	public String subject(){
		if (id != null) {
			  int sid = Integer.valueOf(id);
			writers =  biz.writers(sid);
			subjects = biz.subjects();
		} else {
			writers =  biz.writers(1);
			subjects = biz.subjects();
		}

	return "su";
		
	}
	public String sub(){
	
			subjects = biz.subjects();
		

	return "sub";
		
	}
	public String listw(){
		
		sts = biz.sts(sid);
	

     return "sts";
	
}
	public String sjst(){
		System.out.println(ssid);
		int tid = Integer.valueOf(ssid);
		
	    int a =	biz.insettestpaper(easy1, commonly1, hard1, easy2, commonly2, hard2, test, tid);
	if (a==0) {
		papers = biz.test(); 
		return "test";
	}
		return null;
		
	}
	public List<TestPaper> getPapers() {
		return papers;
	}
	public void setPapers(List<TestPaper> papers) {
		this.papers = papers;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public List<Classes> getCla() {
		return cla;
	}
	public void setCla(List<Classes> cla) {
		this.cla = cla;
	}
	public String getCla1() {
		return cla1;
	}
	public void setCla1(String cla1) {
		this.cla1 = cla1;
	}

	public TestPaper getTest() {
		return test;
	}
	public void setTest(TestPaper test) {
		this.test = test;
	}
	public List<Writer> getWriters() {
		return writers;
	}
	public void setWriters(List<Writer> writers) {
		this.writers = writers;
	}
	public List<Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSsid() {
		return ssid;
	}
	public void setSsid(String ssid) {
		this.ssid = ssid;
	}
	public int[] getTest1() {
		return test1;
	}
	public void setTest1(int[] test1) {
		this.test1 = test1;
	}
	public int[] getNumber() {
		return number;
	}
	public void setNumber(int[] number) {
		this.number = number;
	}
	public Integer[] getIdd() {
		return idd;
	}
	public void setIdd(Integer[] idd) {
		this.idd = idd;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getEasy1() {
		return easy1;
	}
	public void setEasy1(int easy1) {
		this.easy1 = easy1;
	}
	public int getCommonly1() {
		return commonly1;
	}
	public void setCommonly1(int commonly1) {
		this.commonly1 = commonly1;
	}
	public int getHard1() {
		return hard1;
	}
	public void setHard1(int hard1) {
		this.hard1 = hard1;
	}
	public int getEasy2() {
		return easy2;
	}
	public void setEasy2(int easy2) {
		this.easy2 = easy2;
	}
	public int getCommonly2() {
		return commonly2;
	}
	public void setCommonly2(int commonly2) {
		this.commonly2 = commonly2;
	}
	public int getHard2() {
		return hard2;
	}
	public void setHard2(int hard2) {
		this.hard2 = hard2;
	}
	public String getSuid() {
		return suid;
	}
	public void setSuid(String suid) {
		this.suid = suid;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<ST> getSts() {
		return sts;
	}
	public void setSts(List<ST> sts) {
		this.sts = sts;
	}


	

}
