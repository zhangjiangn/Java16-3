package dao.imp;

import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.Restrictions;

import po.Answer;
import po.Classes;
import po.ST;
import po.Student;
import po.TestPaper;
import po.Writer;
import tools.PageBean;

import dao.StudentEaxmDao;

public class StudentEaxmDaoImp implements StudentEaxmDao {

	public List<TestPaper> list(int sid) {
		System.out.println(sid);
		Student student = (Student) session.get(Student.class, sid);
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("cla", student.getClasses().getCname())).add(
				Restrictions.or(Restrictions.eq("state", 2), Restrictions.eq(
						"state", 1)));

		return criteria.list();
	}

	public Student student(int sid) {

		return (Student) session.get(Student.class, sid);

	}

	public TestPaper paper(int tid) {
		// TODO Auto-generated method stub
		return (TestPaper) session.get(TestPaper.class, tid);
	}

	public List<ST> Writerlist1(int tid, int did) {
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(ST.class).add(
				Restrictions.eq("testPaper", paper));
		List<ST> s = criteria.list();
		for (ST st : s) {
			Writer writer = (Writer) session.get(Writer.class, st.getWriter()
					.getWid());
			Student student = (Student) session.get(Student.class, did);
			Answer answer = new Answer();
			answer.setStudent(student);
			answer.setWriter(writer);
			answer.setTestPaper(paper);
			session.beginTransaction();
			session.save(answer);
			System.out.println("45566");
			session.getTransaction().commit();
		}
		return s;
	}

	public List<ST> Writerlist(int tid) {
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(ST.class).add(
				Restrictions.eq("testPaper", paper));
		List<ST> s = criteria.list();

		return s;
	}

	public ST Writerlist(int tid, int p) {
		System.out.println(p);
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(ST.class).add(
				Restrictions.eq("testPaper", paper));
		PageBean bean = new PageBean();
		List<ST> s = criteria.list();
		System.out.println(s);
		ST a = s.get(p - 1);
		System.out.println(a);
		return a;
	}

	public PageBean pagelist(int tid) {
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(ST.class).add(
				Restrictions.eq("testPaper", paper));
		List<ST> s = criteria.list();
		PageBean bean = new PageBean();
		bean.setCount(s.size());
		bean.setPagesize(1);
		bean.getPagetotal();
		bean.getP();
		return bean;
	}

	public int updaan(int wid, String s) {
		int a = 0;
		try {
			Writer writer = (Writer) session.get(Writer.class, wid);
			System.out.println(writer + "writer+-");
			Criteria criteria = session.createCriteria(Answer.class).add(
					Restrictions.eq("writer", writer));
			System.out.println(criteria);
			List<Answer> answer = criteria.list();
			for (Answer answer2 : answer) {
				System.out.println(answer2.getAid() + "��id");
				answer2.setStuans(s);
				session.beginTransaction();
				session.update(answer2);
				session.getTransaction().commit();
			}
		} catch (Exception e) {
			a = 1;
		}

		return a;
	}

	public List<Answer> answers(int sid) {
		TestPaper paper = (TestPaper) session.get(TestPaper.class, sid);
		Criteria criteria = session.createCriteria(Answer.class).add(
				Restrictions.eq("testPaper", paper));
		return criteria.list();
	}

	public int uptest(int sid) {
		int a = 0;
		try {
			TestPaper paper = (TestPaper) session.get(TestPaper.class, sid);
			paper.setState(3);
			session.beginTransaction();
			session.update(paper);
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return a;
	}

}
