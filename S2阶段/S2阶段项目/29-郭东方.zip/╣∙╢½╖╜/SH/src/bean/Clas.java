package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Clas entity. @author MyEclipse Persistence Tools
 */

public class Clas implements java.io.Serializable {

	// Fields

	private Integer cid;
	private String cname;
	private Set students = new HashSet(0);

	// Constructors

	/** default constructor */
	public Clas() {
	}

	/** minimal constructor */
	public Clas(Integer cid) {
		this.cid = cid;
	}

	/** full constructor */
	public Clas(Integer cid, String cname, Set students) {
		this.cid = cid;
		this.cname = cname;
		this.students = students;
	}

	// Property accessors

	public Integer getCid() {
		return this.cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

}