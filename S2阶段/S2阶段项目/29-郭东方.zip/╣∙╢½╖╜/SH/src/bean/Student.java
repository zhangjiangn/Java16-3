package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Jd jd;
	private Clas clas;
	private Fx fx;
	private String sname;
	private String spwd;
	private String sex;
	private String startime;
	private String birthday;
	private String idcard;
	private String shengfen;
	private String city;
	private String tel;
	private String address;
	private Set cjs = new HashSet(0);
	private Set das = new HashSet(0);

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(Integer sid) {
		this.sid = sid;
	}

	/** full constructor */
	public Student(Integer sid, Jd jd, Clas clas, Fx fx, String sname,
			String spwd, String sex, String startime, String birthday,
			String idcard, String shengfen, String city, String tel,
			String address, Set cjs, Set das) {
		this.sid = sid;
		this.jd = jd;
		this.clas = clas;
		this.fx = fx;
		this.sname = sname;
		this.spwd = spwd;
		this.sex = sex;
		this.startime = startime;
		this.birthday = birthday;
		this.idcard = idcard;
		this.shengfen = shengfen;
		this.city = city;
		this.tel = tel;
		this.address = address;
		this.cjs = cjs;
		this.das = das;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Jd getJd() {
		return this.jd;
	}

	public void setJd(Jd jd) {
		this.jd = jd;
	}

	public Clas getClas() {
		return this.clas;
	}

	public void setClas(Clas clas) {
		this.clas = clas;
	}

	public Fx getFx() {
		return this.fx;
	}

	public void setFx(Fx fx) {
		this.fx = fx;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getStartime() {
		return this.startime;
	}

	public void setStartime(String startime) {
		this.startime = startime;
	}

	public String getBirthday() {
		return this.birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getIdcard() {
		return this.idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getShengfen() {
		return this.shengfen;
	}

	public void setShengfen(String shengfen) {
		this.shengfen = shengfen;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Set getCjs() {
		return this.cjs;
	}

	public void setCjs(Set cjs) {
		this.cjs = cjs;
	}

	public Set getDas() {
		return this.das;
	}

	public void setDas(Set das) {
		this.das = das;
	}

}