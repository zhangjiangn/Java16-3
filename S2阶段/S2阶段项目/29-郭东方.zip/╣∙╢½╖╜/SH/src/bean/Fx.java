package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Fx entity. @author MyEclipse Persistence Tools
 */

public class Fx implements java.io.Serializable {

	// Fields

	private Integer fid;
	private String fname;
	private Set students = new HashSet(0);
	private Set sjs = new HashSet(0);
	private Set kms = new HashSet(0);
	private Set sts = new HashSet(0);

	// Constructors

	/** default constructor */
	public Fx() {
	}

	/** minimal constructor */
	public Fx(Integer fid) {
		this.fid = fid;
	}

	/** full constructor */
	public Fx(Integer fid, String fname, Set students, Set sjs, Set kms, Set sts) {
		this.fid = fid;
		this.fname = fname;
		this.students = students;
		this.sjs = sjs;
		this.kms = kms;
		this.sts = sts;
	}

	// Property accessors

	public Integer getFid() {
		return this.fid;
	}

	public void setFid(Integer fid) {
		this.fid = fid;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public Set getStudents() {
		return this.students;
	}

	public void setStudents(Set students) {
		this.students = students;
	}

	public Set getSjs() {
		return this.sjs;
	}

	public void setSjs(Set sjs) {
		this.sjs = sjs;
	}

	public Set getKms() {
		return this.kms;
	}

	public void setKms(Set kms) {
		this.kms = kms;
	}

	public Set getSts() {
		return this.sts;
	}

	public void setSts(Set sts) {
		this.sts = sts;
	}

}