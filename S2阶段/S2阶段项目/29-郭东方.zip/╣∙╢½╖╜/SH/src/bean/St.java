package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * St entity. @author MyEclipse Persistence Tools
 */

public class St implements java.io.Serializable {

	// Fields

	private Integer stid;
	private Jd jd;
	private Fx fx;
	private Km km;
	private String tmdl;
	private String tmtype;
	private String tname;
	private String aoption;
	private String boption;
	private String coption;
	private String doption;
	private String daan;
	private String nandu;
	private String zhangjie;
	private Set sses = new HashSet(0);
	private Set das = new HashSet(0);

	// Constructors

	/** default constructor */
	public St() {
	}

	/** minimal constructor */
	public St(Integer stid) {
		this.stid = stid;
	}

	/** full constructor */
	public St(Integer stid, Jd jd, Fx fx, Km km, String tmdl, String tmtype,
			String tname, String aoption, String boption, String coption,
			String doption, String daan, String nandu, String zhangjie,
			Set sses, Set das) {
		this.stid = stid;
		this.jd = jd;
		this.fx = fx;
		this.km = km;
		this.tmdl = tmdl;
		this.tmtype = tmtype;
		this.tname = tname;
		this.aoption = aoption;
		this.boption = boption;
		this.coption = coption;
		this.doption = doption;
		this.daan = daan;
		this.nandu = nandu;
		this.zhangjie = zhangjie;
		this.sses = sses;
		this.das = das;
	}

	// Property accessors

	public Integer getStid() {
		return this.stid;
	}

	public void setStid(Integer stid) {
		this.stid = stid;
	}

	public Jd getJd() {
		return this.jd;
	}

	public void setJd(Jd jd) {
		this.jd = jd;
	}

	public Fx getFx() {
		return this.fx;
	}

	public void setFx(Fx fx) {
		this.fx = fx;
	}

	public Km getKm() {
		return this.km;
	}

	public void setKm(Km km) {
		this.km = km;
	}

	public String getTmdl() {
		return this.tmdl;
	}

	public void setTmdl(String tmdl) {
		this.tmdl = tmdl;
	}

	public String getTmtype() {
		return this.tmtype;
	}

	public void setTmtype(String tmtype) {
		this.tmtype = tmtype;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getAoption() {
		return this.aoption;
	}

	public void setAoption(String aoption) {
		this.aoption = aoption;
	}

	public String getBoption() {
		return this.boption;
	}

	public void setBoption(String boption) {
		this.boption = boption;
	}

	public String getCoption() {
		return this.coption;
	}

	public void setCoption(String coption) {
		this.coption = coption;
	}

	public String getDoption() {
		return this.doption;
	}

	public void setDoption(String doption) {
		this.doption = doption;
	}

	public String getDaan() {
		return this.daan;
	}

	public void setDaan(String daan) {
		this.daan = daan;
	}

	public String getNandu() {
		return this.nandu;
	}

	public void setNandu(String nandu) {
		this.nandu = nandu;
	}

	public String getZhangjie() {
		return this.zhangjie;
	}

	public void setZhangjie(String zhangjie) {
		this.zhangjie = zhangjie;
	}

	public Set getSses() {
		return this.sses;
	}

	public void setSses(Set sses) {
		this.sses = sses;
	}

	public Set getDas() {
		return this.das;
	}

	public void setDas(Set das) {
		this.das = das;
	}

}