package dao;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import bean.Sj;



public class ZaixianDao implements biz.ZaixianBiz{

	public List<Object[]> selectsj() {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select k.kname,c.startime,s.* from sj s,cj c,km k,student u where s.kid=k.kid and u.cid=c.cid and c.sid=u.sid";
		SQLQuery query=session.createSQLQuery(sql);
		List<Object[]> list=query.list();
		return list;
	}

	public List<Object[]> sj(int sjid) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select k.kname,c.startime,s.stime,s.zongfen,count(t.stid) " +
				"from sj s,cj c,km k,student u,st t " +
				"where s.kid=k.kid and u.cid=c.cid and c.sid=u.sid and s.sjid=? and t.kid=k.kid " +
				"group by k.kname,c.startime,s.stime,s.zongfen";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,sjid);
		List<Object[]> list=query.list();
		return list;
	}

	public List<Object[]> st(int sjid) {
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select o.ssid from st s,sj j,ss o where o.sjid=? and o.sjid=j.sjid and o.stid=s.stid";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,sjid);
		List<Object[]> list=query.list();
		return list;
	}

	public List<Object[]> selst(int ssid) {
	
		Session session= HibernateSessionFactory.getSessionFactory().openSession();
		String sql="select s.* from st s,sj j,ss o where o.ssid=? and o.sjid=j.sjid and o.stid=s.stid";
		SQLQuery query=session.createSQLQuery(sql);
		query.setInteger(0,ssid);
		List<Object[]> list=query.list();
		return list;
	}

}
