package biz.imp;



import dao.StudentLoginDao;
import dao.imp.StudentLoginDaoImp;
import po.Acc;
import po.Student;

import biz.StudentLoginBiz;

public class StudentLoginBizImp implements StudentLoginBiz {
	StudentLoginDao studentDao = new StudentLoginDaoImp();

	public Acc AccLogin(String name, String pwd) {
		// TODO Auto-generated method stub
		return studentDao.AccLogin(name, pwd);
	}

	public Student StudentLogin(String name, String pwd) {
		// TODO Auto-generated method stub
		return studentDao.StudentLogin(name, pwd);
	}







}
