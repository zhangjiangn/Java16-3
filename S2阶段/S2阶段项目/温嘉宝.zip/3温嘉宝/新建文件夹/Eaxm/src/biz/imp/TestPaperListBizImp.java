package biz.imp;

import java.sql.Timestamp;
import java.util.List;


import dao.TestPaperListDao;
import dao.imp.TestPaperListDaoImp;




import po.Classes;
import po.ST;
import po.Subject;
import po.Writer;

import po.TestPaper;
import tools.PageBean;
import biz.TestPaperListBiz;

public class TestPaperListBizImp implements TestPaperListBiz {
	TestPaperListDao dao = new TestPaperListDaoImp();
	public  List<TestPaper> test(int p) {
		// TODO Auto-generated method stub
		return dao.test(p);
	}
	public int upId(int tid) {
		// TODO Auto-generated method stub
		return dao.upId(tid);
	}
	public int delete(int tid) {
		// TODO Auto-generated method stub
		return dao.delete(tid);
	}
	
	public TestPaper testList(int sid) {
		// TODO Auto-generated method stub
		return dao.testList(sid);
	}
	public List<Classes> clalist() {
		// TODO Auto-generated method stub
		return dao.clalist();
	}
	public int update(int tid, String classes, String time,String time1) {
		// TODO Auto-generated method stub
		return dao.update(tid, classes, time,time1);
	}
	public List<Subject> subjects() {
		// TODO Auto-generated method stub
		return dao.subjects();
	}
	public List<Writer> writers(int sid,int p) {
		// TODO Auto-generated method stub
		return dao.writers(sid,p);
	}
	public int insettestpaper(int[] test1, TestPaper testPaper, int sid) {
		// TODO Auto-generated method stub
		return dao.insettestpaper(test1, testPaper, sid);
	}

	public int insettestpaper(int a, int b, int c, int a1, int b1, int c1,
			TestPaper testPaper, int sid) {
		// TODO Auto-generated method stub
		return dao.insettestpaper(a, b, c, a1, b1, c1, testPaper, sid);
	}
	public List<TestPaper> test(int sid, int state) {
		// TODO Auto-generated method stub
		return dao.test(sid, state);
	}
	public List<ST> sts(int sid) {
		// TODO Auto-generated method stub
		return dao.sts(sid);
	}
	public int upda(int tid, String classes, String time, String time1) {
		// TODO Auto-generated method stub
		return dao.upda(tid, classes, time, time1);
	}
	public PageBean pagelist(int sid) {
		// TODO Auto-generated method stub
		return dao.pagelist(sid);
	}
	public Subject subjects(int sid) {
		// TODO Auto-generated method stub
		return dao.subjects(sid);
	}
	public PageBean pagelist() {
		// TODO Auto-generated method stub
		return dao.pagelist();
	}
	

	

}
