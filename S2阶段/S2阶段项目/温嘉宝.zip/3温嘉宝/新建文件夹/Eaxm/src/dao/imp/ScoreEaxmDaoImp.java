package dao.imp;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import po.Answer;
import po.Scores;
import po.Student;
import po.Subject;
import po.TestPaper;
import tools.PageBean;
import dao.ScoreEaxmDao;

public class ScoreEaxmDaoImp implements ScoreEaxmDao {
	public List<TestPaper> list(int sid,int p) {
		System.out.println(sid);
		Student student = (Student) session.get(Student.class, sid);
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("cla", student.getClasses().getCname())).add(
				Restrictions.eq("state", 3));
		criteria.setFirstResult((p-1)*6);
		criteria.setMaxResults(6);
		return criteria.list();
	}
	public PageBean pagelist(int sid) {
		System.out.println(sid);
		Student student = (Student) session.get(Student.class, sid);
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("cla", student.getClasses().getCname())).add(
				Restrictions.eq("state", 3));
		List<TestPaper> list =   criteria.list();
		PageBean bean = new PageBean();
		bean.setCount(list.size());
		bean.setPagesize(6);
		System.out.println(bean.getPagetotal());
		System.out.println(bean.getP());
		return bean;
	}
	public List<TestPaper> list(int p) {
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("state", 3));
		    criteria.setFirstResult((p-1)*6);
		    criteria.setMaxResults(6);
		return criteria.list();
	}
	public PageBean pagelist() {
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("state", 3));
		List<TestPaper> list =   criteria.list();
		PageBean bean = new PageBean();
		bean.setCount(list.size());
		bean.setPagesize(6);
		System.out.println(bean.getPagetotal());
		System.out.println(bean.getP());
		return bean;
	}

	public List<Subject> subjects() {

		return session.createQuery("from Subject").list();

	}

	public List<TestPaper> sulist(int sid) {
		Subject subject = (Subject) session.get(Subject.class, sid);
		Criteria criteria = session.createCriteria(TestPaper.class).add(
				Restrictions.eq("state", 3)).add(
				Restrictions.eq("subject", subject));
		return criteria.list();

	}

	public List<Scores> scores(int sid, int tid) {
		Student student = (Student) session.get(Student.class, sid);
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(Scores.class).add(
				Restrictions.eq("testPaper", paper)).add(
				Restrictions.eq("student", student));

		return criteria.list();

	}

	public List<Scores> scores(int tid) {

		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(Scores.class).add(
				Restrictions.eq("testPaper", paper));

		return criteria.list();

	}

	public Scores sco(int sid) {

		return (Scores) session.get(Scores.class, sid);

	}

	public List<Answer> answers(int tid) {
		TestPaper paper = (TestPaper) session.get(TestPaper.class, tid);
		Criteria criteria = session.createCriteria(Answer.class).add(
				Restrictions.eq("testPaper", paper));

		return criteria.list();

	}
}
