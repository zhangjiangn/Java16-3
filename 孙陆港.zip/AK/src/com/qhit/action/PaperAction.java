package com.qhit.action;

import java.util.ArrayList;

import org.apache.struts2.ServletActionContext;

import com.qhit.bean.Classs;
import com.qhit.bean.Direction;
import com.qhit.bean.ExamQuestion;
import com.qhit.bean.Level;
import com.qhit.bean.Paper;
import com.qhit.bean.Stage;
import com.qhit.bean.Subject;
import com.qhit.bean.Tatus;
import com.qhit.biz.PaperBiz;
import com.qhit.biz.impl.PaperBizImpl;
import com.qhit.util.PageBean;

public class PaperAction {
	private PaperBiz pb = new PaperBizImpl();
	private ArrayList<Direction> dirList;
	private ArrayList<Stage> staList;
	private ArrayList<Subject> subList;
	private ArrayList<Tatus> examTatusList;
	private PageBean paperPb;
	private ArrayList<Paper> paperList;
	private int p ;
	private int pid;
	private String dirOpValue;
	private String staOpValue;
	private int dirSelect;
	private int staSelect;
	private int subSelect;
	private int tatusSelect;
	private PageBean EQPb;
	private Paper paper;
	private ArrayList checkbox ;
	private String parDir;
	private String parSta;
	private int parTatus;
	private int YESOrNO;
	private ArrayList<ExamQuestion> EQList;
	private ArrayList<Classs> classsList;
	private ArrayList classsId;
	private ArrayList pstartTimeList;
	private ArrayList pfinishTimeList;
	private Level level;
	
	
	
	
	//������
	
	public String randomPaper(){
		dirList =  pb.getDirList();
		staList = pb.getStageList();
		subList = pb.getSubjectListByDidAndStaid(1, 1);
		return "randomPaper";
	}
	
	public String randomPaperDirAndStaChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList =  pb.getDirList();
		staList = pb.getStageList();
		subList = pb.getSubjectListByDidAndStaid(did, staid);
		return "randomPaper";
	}
	
	public String randomPaperStart(){
		int psubid = subSelect;
		int i= pb.addPaper(paper, psubid);
		if (i == 1) {
			int pid = pb.getPaperDescID();
			int j = pb.addPaperEq(pid, level);
			if (j == 1) {
				ServletActionContext.getRequest().getSession().setAttribute("intext", "����ɹ�");
				return "info";
			} else {
				ServletActionContext.getRequest().getSession().setAttribute("intext", "���ʧ��,�ÿ�Ŀ�µ��������,����ⲻ����֧��������!");
				return "info";
			}
		} else {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�Ծ�����ʧ��!");
			return "info";
		}
	}
	
	
	//ɾ���Ծ�
	public String deletePaperAndPaperEQ(){
		int i = pb.deletePaperAndPaperEQ(pid);
		if (i == 1) {
			return "PaperIndex";
		} else {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�������:DPAEQ0,����Ա����Ŭ���޸���!�����ĵȴ�!");
			return "info";
		}
	}
	//��������
	public String FinishExam(){
		int i = pb.FinishExam(pid);
		if (i == 1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�����ѽ���!");
			return "info";
		} else {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�������:FEI0,����Ա����Ŭ���޸���!�����ĵȴ�!");
			return "info";
		}
	}
	
	/****************************
	 * ��ʼ����
	 * @return
	 */
	public String StartExam(){
		System.out.println(pid);
		int i = pb.StartExam(pid);
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�����ѿ�ʼ");
			return "info";
		} else {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�������©��,����ά��,����Ա���ڼӰ�ӵ��Ŭ���޸���!");
			return "info";
		}
	}
	
	//����ʼ����ҳ��
	public String ExamStart(){
		paperList = pb.getPaperById(pid);
		classsList = pb.getCalsss();
		return "ExamStart";
	}
	//��ʼ����֮ �༶ ���� ���� �������� 
	public String ExamStartRun(){
		ArrayList<Paper> paperList1 = new ArrayList<Paper>();
		for (Object obj : classsId) {
			for (Object obj1 : pstartTimeList) {
				for (Object obj2 : pfinishTimeList) {
					Paper paper = new Paper(); 
					int cid= Integer.parseInt(obj.toString());
					String pstartTime = obj1.toString();
					String pfinishTime = obj2.toString();
					Classs cla = new Classs();
					cla.setCid(cid);
					paper.setClasss(cla);
					paper.setPstartTime(pstartTime);
					paper.setPfinishTime(pfinishTime);
					paper.setPid(pid);
					paperList1.add(paper);
				}
			}
		}
		int i = pb.updateIStart(paperList1); 
		if (i==1) {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�༶�������Ѹ��£�");
			return "info";
		} else {
			ServletActionContext.getRequest().getSession().setAttribute("intext", "�������©��,����ά��,����Ա���ڼӰ�ӵ��Ŭ���޸���!");
			return "info";
		}
		
		
	}
	
	
	
	public String isPageBean(){
		if (YESOrNO==1) {
			onChange();
		} else {
			selectChange();
		}
		return "paperIndex";
	}
	
	public String lookPaperEQ(){
		paperList = pb.getPaperById(pid);
		EQList = pb.getExamQuestionByEqPid(pid);
		
		return "lookPaperEQ";
	}
	
	public String PaperIndex(){
		dirList =  pb.getDirList();
		staList = pb.getStageList();
		subList = pb.getSubjectListByDidAndStaid(1, 1);
		examTatusList = pb.getExamTatus(1);
		int up=1;
		String pfirstType="����";
		if (p!=0) up=p;
		paperPb = pb.getPaperByPageBean(up, pfirstType);
		YESOrNO=1;
		return "paperIndex";
	}
	
	public String selectChange(){
		if (dirSelect==0||staSelect==0||tatusSelect==0) {
			dirSelect=Integer.parseInt(parDir);
			staSelect=Integer.parseInt(parSta);
			tatusSelect=parTatus;
		}
		dirList =  pb.getDirList(dirSelect);
		staList = pb.getStageList(staSelect);
		subList = pb.getSubjectListByDidAndStaid(dirSelect, staSelect);
		examTatusList = pb.getExamTatus(1);
		int up=1;
		if (p!=0) up=p;
		paperPb = pb.getPaperByPageBean(up, subSelect, tatusSelect);
		YESOrNO=2;
		return "paperIndex";
	}
	
	public String onChange(){
		if (dirOpValue==null||staOpValue==null) {
			dirOpValue=parDir;
			staOpValue=parSta;
		}
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList =  pb.getDirList();
		staList = pb.getStageList();
		subList = pb.getSubjectListByDidAndStaid(did, staid);
		examTatusList = pb.getExamTatus(1);
		int up=1;
		if (p!=0) up=p;
		Subject sub= subList.get(0);
		int psubid=sub.getSubid();
		paperPb = pb.getPaperByPageBeanBySubid(up, psubid);
		YESOrNO=1;
		return "paperIndex";
	}
	
	public String subOnChange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList =  pb.getDirList(did);
		staList = pb.getStageList(staid);
		subList = pb.getSubjectListByDidAndStaid(did, staid);
		examTatusList = pb.getExamTatus(1);
		int up=1;
		if (p!=0) up=p;
		paperPb = pb.getPaperByPageBeanBySubid(up, subSelect);
		
		return "paperIndex";
	}
	
	
	public String choosePaper(){
		dirList =  pb.getDirList(1);
		staList = pb.getStageList(1);
		subList = pb.getSubjectListByDidAndStaid(1, 1);
		int up=1;
		if (p!=0)up=p;
		Subject sub = subList.get(0);
		int esubid= sub.getSubid();
		EQPb = pb.getExamQuestionByPageBean(up,esubid);
		
		return "choosePaper";
		
	}
	
	public String choosePaperOnchange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList =  pb.getDirList();
		staList = pb.getStageList();
		subList = pb.getSubjectListByDidAndStaid(did, staid);
		int up=1;
		if (p!=0)up=p;
		Subject sub = subList.get(0);
		int esubid= sub.getSubid();
		EQPb = pb.getExamQuestionByPageBean(up,esubid);
		
		return "choosePaper";
		
	}
	public String choosePaperSubOnchange(){
		int did = Integer.parseInt(dirOpValue);
		int staid = Integer.parseInt(staOpValue);
		dirList =  pb.getDirList(did);
		staList = pb.getStageList(staid);
		subList = pb.getSubjectListByDidAndStaid(did, staid);
		int up=1;
		if (p!=0)up=p;
		EQPb = pb.getExamQuestionByPageBean(up,subSelect);
		
		return "choosePaper";
		
	}
	
	public String choosePaperStart(){
		int eid = 0;
		int psubid = subSelect;
		int i= pb.addPaper(paper, psubid);
		if (i == 1) {
			int pid = pb.getPaperDescID();
			for (Object o : checkbox) {
				eid = Integer.parseInt(o.toString());
				int j = pb.addPaper_EQ(pid, eid);
				if (j ==1 ) {
					System.out.println("�ɹ�");
				} else {
					System.out.println("ʧ��");
				}
			}
			ServletActionContext.getRequest().getSession().setAttribute("intext", "���ӳɹ�");
			return "info";
		}else{
			return "info";
		}
		
		
		
		
		
	}
	
	public ArrayList<Direction> getDirList() {
		return dirList;
	}
	public void setDirList(ArrayList<Direction> dirList) {
		this.dirList = dirList;
	}
	public ArrayList<Stage> getStaList() {
		return staList;
	}
	public void setStaList(ArrayList<Stage> staList) {
		this.staList = staList;
	}
	public PaperBiz getPb() {
		return pb;
	}
	public void setPb(PaperBiz pb) {
		this.pb = pb;
	}
	
	
	public PageBean getPaperPb() {
		return paperPb;
	}
	public void setPaperPb(PageBean paperPb) {
		this.paperPb = paperPb;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public ArrayList<Tatus> getExamTatusList() {
		return examTatusList;
	}
	public void setExamTatusList(ArrayList<Tatus> examTatusList) {
		this.examTatusList = examTatusList;
	}
	
	public ArrayList<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(ArrayList<Paper> paperList) {
		this.paperList = paperList;
	}

	public ArrayList<Subject> getSubList() {
		return subList;
	}
	public void setSubList(ArrayList<Subject> subList) {
		this.subList = subList;
	}

	public String getDirOpValue() {
		return dirOpValue;
	}

	public void setDirOpValue(String dirOpValue) {
		this.dirOpValue = dirOpValue;
	}

	public String getStaOpValue() {
		return staOpValue;
	}

	public void setStaOpValue(String staOpValue) {
		this.staOpValue = staOpValue;
	}

	public int getDirSelect() {
		return dirSelect;
	}

	public void setDirSelect(int dirSelect) {
		this.dirSelect = dirSelect;
	}

	public int getStaSelect() {
		return staSelect;
	}

	public void setStaSelect(int staSelect) {
		this.staSelect = staSelect;
	}

	public int getSubSelect() {
		return subSelect;
	}

	public void setSubSelect(int subSelect) {
		this.subSelect = subSelect;
	}

	public int getTatusSelect() {
		return tatusSelect;
	}

	public void setTatusSelect(int tatusSelect) {
		this.tatusSelect = tatusSelect;
	}

	public PageBean getEQPb() {
		return EQPb;
	}

	public void setEQPb(PageBean eQPb) {
		EQPb = eQPb;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public ArrayList getCheckbox() {
		return checkbox;
	}

	public void setCheckbox(ArrayList checkbox) {
		this.checkbox = checkbox;
	}

	public int getYESOrNO() {
		return YESOrNO;
	}

	public void setYESOrNO(int yESOrNO) {
		YESOrNO = yESOrNO;
	}

	public String getParDir() {
		return parDir;
	}

	public void setParDir(String parDir) {
		this.parDir = parDir;
	}

	public String getParSta() {
		return parSta;
	}

	public void setParSta(String parSta) {
		this.parSta = parSta;
	}

	public int getParTatus() {
		return parTatus;
	}

	public void setParTatus(int parTatus) {
		this.parTatus = parTatus;
	}

	public ArrayList<ExamQuestion> getEQList() {
		return EQList;
	}

	public void setEQList(ArrayList<ExamQuestion> eQList) {
		EQList = eQList;
	}

	public ArrayList<Classs> getClasssList() {
		return classsList;
	}

	public void setClasssList(ArrayList<Classs> classsList) {
		this.classsList = classsList;
	}

	public ArrayList getClasssId() {
		return classsId;
	}

	public void setClasssId(ArrayList classsId) {
		this.classsId = classsId;
	}

	public ArrayList getPstartTimeList() {
		return pstartTimeList;
	}

	public void setPstartTimeList(ArrayList pstartTimeList) {
		this.pstartTimeList = pstartTimeList;
	}

	public ArrayList getPfinishTimeList() {
		return pfinishTimeList;
	}

	public void setPfinishTimeList(ArrayList pfinishTimeList) {
		this.pfinishTimeList = pfinishTimeList;
	}

	public Level getLevel() {
		return level;
	}

	public void setLevel(Level level) {
		this.level = level;
	}
	
}
