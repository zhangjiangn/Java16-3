package com.qhit.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;

import com.qhit.bean.Direction;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.bean.Users;
import com.qhit.dao.LoginDao;

public class LoginDaoImpl implements LoginDao {

	public Student getUsersByStu(String name, String pwd) {
		Student u = null;
		String hql = "from Student where sname=:name and spwd=:pwd";
		Query query= session.createQuery(hql);
		query.setString("name", name);
		query.setString("pwd", pwd);
		u=(Student) query.uniqueResult();
		return u;
		
	}

	public Users getUsersByUsers(String name, String pwd) {
		Users u =null;
		String hql = "from Users where uname=:name and upwd=:pwd";
		Query query= session.createQuery(hql);
		query.setString("name", name);
		query.setString("pwd", pwd);
		u=(Users) query.uniqueResult();
		return u;
	}

	
}
