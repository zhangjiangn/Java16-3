package com.qhit.biz.impl;

import java.util.ArrayList;

import com.qhit.bean.Direction;
import com.qhit.bean.Paper;
import com.qhit.bean.Score;
import com.qhit.bean.Stage;
import com.qhit.bean.Student;
import com.qhit.bean.Subject;
import com.qhit.biz.ScoreBiz;
import com.qhit.dao.ScoreDao;
import com.qhit.dao.impl.ScoreDaoImpl;
import com.qhit.util.PageBean;

public class ScoreBizImpl implements ScoreBiz {
	
	private ScoreDao sd = new ScoreDaoImpl();
	
	public ArrayList<Direction> getDirList() {
		return sd.getDirList();
	}

	public PageBean getPaperByPageBean(int p, int psubid) {
		return sd.getPaperByPageBean(p, psubid);
	}

	public ArrayList<Stage> getStageList() {
		return sd.getStageList();
	}

	public ArrayList<Subject> getSubjectList() {
		return sd.getSubjectList();
	}

	public ArrayList<Subject> getSubjectListByDidAndStaid(int subdid,
			int substaid) {
		return sd.getSubjectListByDidAndStaid(subdid, substaid);
	}

	public ArrayList<Score> getScoreByPid(int pid) {
		return sd.getScoreByPid(pid);
	}

	public ArrayList<Paper> getPaper(int pid) {
		return sd.getPaper(pid);
	}

	public int getCountBypid(int pid) {
		return sd.getCountBypid(pid);
	}

	public int getPassCount(int pid) {
		return sd.getPassCount(pid);
	}

	public ArrayList<Score> getScoreByPidAndSid(int pid, int sid) {
		return sd.getScoreByPidAndSid(pid, sid);
	}

	public ArrayList<Student> getStudentsByNameStr(String snameStr) {
		return sd.getStudentsByNameStr(snameStr);
	}

	
}
