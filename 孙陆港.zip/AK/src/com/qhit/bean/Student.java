package com.qhit.bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private Integer sid;
	private Classs classs;
	private Direction direction;
	private String sname;
	private String spwd;
	private Integer ssubid;
	private Set scores = new HashSet(0);
	private Set stuPaperEqs = new HashSet(0);

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** minimal constructor */
	public Student(Integer sid) {
		this.sid = sid;
	}

	/** full constructor */
	public Student(Integer sid, Classs classs, Direction direction,
			String sname, String spwd, Integer ssubid, Set scores,
			Set stuPaperEqs) {
		this.sid = sid;
		this.classs = classs;
		this.direction = direction;
		this.sname = sname;
		this.spwd = spwd;
		this.ssubid = ssubid;
		this.scores = scores;
		this.stuPaperEqs = stuPaperEqs;
	}

	// Property accessors

	public Integer getSid() {
		return this.sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Classs getClasss() {
		return this.classs;
	}

	public void setClasss(Classs classs) {
		this.classs = classs;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSpwd() {
		return this.spwd;
	}

	public void setSpwd(String spwd) {
		this.spwd = spwd;
	}

	public Integer getSsubid() {
		return this.ssubid;
	}

	public void setSsubid(Integer ssubid) {
		this.ssubid = ssubid;
	}

	public Set getScores() {
		return this.scores;
	}

	public void setScores(Set scores) {
		this.scores = scores;
	}

	public Set getStuPaperEqs() {
		return this.stuPaperEqs;
	}

	public void setStuPaperEqs(Set stuPaperEqs) {
		this.stuPaperEqs = stuPaperEqs;
	}

}