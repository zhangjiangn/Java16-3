package com.qhit.bean;

/**
 * PaperEq entity. @author MyEclipse Persistence Tools
 */

public class PaperEq implements java.io.Serializable {

	// Fields

	private Integer peid;
	private Paper paper;
	private ExamQuestion examQuestion;
	private int num;

	// Constructors

	/** default constructor */
	public PaperEq() {
	}

	/** minimal constructor */
	public PaperEq(Integer peid) {
		this.peid = peid;
	}

	/** full constructor */
	public PaperEq(Integer peid, Paper paper, ExamQuestion examQuestion) {
		this.peid = peid;
		this.paper = paper;
		this.examQuestion = examQuestion;
	}

	// Property accessors

	public Integer getPeid() {
		return this.peid;
	}

	public void setPeid(Integer peid) {
		this.peid = peid;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public ExamQuestion getExamQuestion() {
		return this.examQuestion;
	}

	public void setExamQuestion(ExamQuestion examQuestion) {
		this.examQuestion = examQuestion;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}